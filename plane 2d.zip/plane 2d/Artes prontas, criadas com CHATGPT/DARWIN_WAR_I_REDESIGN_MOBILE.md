# DARWIN WAR I — Redesign Mobile

**Documento de especificação para Antigravity / Codex**  
**Projeto:** DARWIN WAR I  
**Tipo:** Jogo mobile arcade de combate aéreo 2D  
**Referência de experiência:** 1945 Air Force  
**Prioridade:** redesign visual e responsividade, preservando integralmente as mecânicas existentes.

---

## 1. Objetivo

Reformular a interface do **DARWIN WAR I** para que pareça um jogo mobile arcade completo e profissional, inspirado na organização visual, na progressão e na apresentação de aeronaves de *1945 Air Force*, mas com identidade própria.

O jogo deve ser projetado primeiro para celulares, em orientação vertical (*portrait*). Não criar uma interface de computador e simplesmente reduzi-la para caber na tela do celular.

O foco desta etapa é reorganizar e melhorar visualmente estas telas:

1. Menu principal.
2. Hangar e seleção de aeronaves.
3. Mapa de campanha e seleção de missões.
4. Oficina de fusão.

O resultado deve destacar as aeronaves, facilitar a navegação por toque e manter as informações importantes legíveis em telas pequenas.

## 2. Regra principal: preservar o jogo existente

**Não reconstruir o jogo do zero e não alterar as mecânicas durante o redesign visual.**

Antes de editar qualquer arquivo:

1. Inspecione a estrutura completa do projeto.
2. Identifique a tecnologia, os componentes, as telas, os estilos e os arquivos de dados existentes.
3. Localize como o jogo salva e carrega o progresso.
4. Identifique os eventos e funções usados pela economia, inventário, aeronaves, campanha, fusão e combate.
5. Apresente um resumo curto da estrutura encontrada e do plano de alteração.
6. Só então implemente o redesign, reutilizando o que já existe sempre que possível.

Preservar integralmente, sem perda de dados ou funcionalidades:

- Moedas de ouro e diamantes.
- Compras, recompensas e economia do jogo.
- Inventário e catálogo de aeronaves.
- Aeronave equipada e seleção de aeronaves.
- Níveis, experiência, estrelas, raridade e atributos.
- Aprimoramentos e evolução.
- Oficina e sistema de fusão.
- Mercado e loja.
- Arsenal, projéteis e armas especiais.
- Conquistas, correio, eventos e missões diárias, quando já implementados.
- Terminal de códigos/cheats, caso já exista.
- Campanha, desbloqueio e conclusão das fases.
- Sistema de combate, inimigos, chefes, vida, dano e projéteis.
- Salvamento local ou remoto e restauração do progresso.
- Sons, configurações e controles já existentes.

Não substituir dados reais por exemplos fictícios. Não remover uma funcionalidade só porque ela ainda não tem uma apresentação visual ideal. Quando uma informação ou função não existir no projeto, não inventá-la: manter a estrutura preparada e informar a ausência.

---

## 3. Dimensões e comportamento mobile

### Referência de desenvolvimento

- Resolução lógica de referência: **390 × 844 px**.
- Proporção aproximada: **9:19,5**.
- Larguras a suportar: **360 px a 430 px**.
- Orientação principal: vertical (*portrait*).
- Usar a altura dinâmica disponível do dispositivo, considerando `100dvh` quando aplicável.
- Respeitar `safe-area-inset-top` e `safe-area-inset-bottom`.
- Evitar rolagem horizontal em todas as telas, exceto carrosséis intencionais.
- Botões e controles devem ter área de toque confortável, preferencialmente de pelo menos 44 × 44 px.
- Textos, painéis e imagens devem se adaptar sem cortes ou sobreposição.
- Não fixar elementos em posições que quebrem em celulares com alturas diferentes.

### Regras de experiência

- Priorizar navegação por toque, sem depender de mouse ou hover.
- Usar botões grandes e claros para as ações principais.
- Manter recursos e navegação consistentes entre as telas.
- Evitar excesso de informação simultânea.
- Usar rolagem vertical somente quando necessária.
- Em telas com carrossel, deixar evidente que há mais itens para o lado.
- Garantir contraste e legibilidade em telas pequenas.

---

## 4. Identidade visual do DARWIN WAR I

**Nome:** DARWIN WAR I  
**Subtítulo:** MILITARY AIR COMBAT

### Direção artística

Criar uma identidade de arcade militar futurista, com referências à apresentação de aeronaves de *1945 Air Force*, sem copiar logotipos, telas ou artes protegidas.

Características desejadas:

- Interface escura, com aparência metálica e militar.
- Painéis com profundidade, bordas e iluminação discreta.
- Detalhes em laranja e azul elétrico.
- Ícones de leitura rápida.
- Tipografia forte, legível e consistente.
- Animações curtas e suaves, sem prejudicar o desempenho.
- Aeronaves como protagonistas das telas.
- Fundos ilustrados de hangares, porta-aviões, oceanos, ilhas e bases militares.

### Paleta de referência

| Uso | Cor | Código |
|---|---|---|
| Fundo principal | Azul-marinho profundo | `#101A2D` |
| Painéis | Azul escuro | `#1D2B42` |
| Aço / bordas | Azul-aço | `#34465F` |
| Destaque principal | Laranja | `#FF9D00` |
| Destaque secundário | Azul elétrico | `#16BDF5` |
| Texto principal | Branco suave | `#F5F7FA` |
| Sucesso / melhoria | Verde | `#20C878` |

A paleta pode receber pequenas variações para estados, raridades e efeitos, mas a identidade geral deve permanecer consistente.

---

## 5. Tela 1 — Menu principal

### Objetivo

Criar uma primeira tela impactante, que apresente imediatamente o universo do DARWIN WAR I e destaque a aeronave atualmente equipada.

### Organização de cima para baixo

**A. Cabeçalho do jogador**

- Avatar do jogador.
- Nível atual.
- Barra de experiência.
- Saldo de moedas de ouro.
- Saldo de diamantes.
- Botões de adição de recursos, caso já existam no jogo.

**B. Identidade do jogo**

- Logo ou título DARWIN WAR I.
- Subtítulo MILITARY AIR COMBAT.
- Fundo ilustrado com atmosfera militar e arcade.

**C. Aeronave protagonista**

- Exibir a aeronave atualmente equipada em tamanho destacado.
- Usar sprite individual, com transparência real.
- Mostrar nome, nível e raridade da aeronave.
- Usar efeitos visuais discretos nos motores, sem exagerar no brilho.
- O fundo pode representar um hangar, porta-aviões, oceano ou cenário militar.

**D. Ação principal**

- Botão grande **DECOLAR**.
- Deve direcionar para a seleção de campanha ou missão, conforme o fluxo existente.
- A ação deve manter o comportamento atual do jogo.

**E. Navegação secundária**

Organizar atalhos em uma área inferior ou em uma grade compacta:

- Hangar.
- Fusão.
- Arsenal.
- Loja.
- Missões diárias.
- Eventos.
- Conquistas.
- Correio.
- Configurações.

Não é necessário exibir todos os atalhos com o mesmo destaque. A ação **DECOLAR** deve continuar sendo o elemento de maior prioridade visual.

---

## 6. Tela 2 — Hangar e seleção de aeronaves

### Objetivo

Transformar a seleção atual em um hangar visual, no qual cada aeronave tenha presença, identidade e informações fáceis de consultar.

### Organização de cima para baixo

**A. Cabeçalho**

- Botão voltar.
- Título HANGAR.
- Ouro e diamantes, mantendo os saldos reais.

**B. Apresentação da aeronave selecionada**

- Aeronave em tamanho grande, centralizada ou em composição equilibrada com o painel de informações.
- Usar PNG individual com transparência real.
- Manter a proporção original do sprite.
- Disponibilizar setas ou gesto de navegação entre aeronaves, se adequado à estrutura atual.
- Mostrar nome, categoria, raridade e estrelas.

**C. Painel de atributos**

Apresentar, conforme os dados já existentes:

- HP.
- Dano.
- Cadência.
- Velocidade.
- Defesa.
- Nível e progresso de evolução.
- Estrelas e raridade.

Não inventar atributos ou valores. Reutilizar os dados reais de cada aeronave.

**D. Categorias**

Criar filtros horizontais, com rolagem lateral:

- Todas.
- Caças.
- Clássicos WWII.
- Bombardeiros.
- Helicópteros.
- Brasileiras.
- Americanas.
- Russas.
- Futuristas.
- Especiais.

Exibir somente as categorias compatíveis com o catálogo disponível. Se alguma categoria ainda não possuir aeronaves, não preencher com itens fictícios.

**E. Inventário / carrossel**

- Miniaturas individuais das aeronaves.
- Nome ou identificação curta.
- Estrelas.
- Indicador de aeronave equipada.
- Indicador de aeronave bloqueada, quando aplicável.
- Seleção por toque.

**F. Ações**

- EQUIPAR.
- APRIMORAR.
- DETALHES.

Os botões devem chamar as funções reais já existentes. Não criar ações meramente decorativas.

### Diretriz importante para as artes

Não usar a spritesheet inteira como imagem de um card. Cada aeronave deve utilizar seu próprio sprite recortado, com fundo transparente, preservando a qualidade e a proporção.

---

## 7. Tela 3 — Campanha e seleção de missões

### Objetivo

Substituir a grade simples de números por um mapa de campanha ilustrado, com progressão visual e sensação de jornada militar.

### Organização da tela

**A. Cabeçalho**

- Botão voltar.
- Título CAMPANHA.
- Ouro e diamantes.

**B. Identificação do capítulo**

- Número e nome do capítulo.
- Região da campanha, por exemplo: Pacífico.
- Progresso do capítulo.
- Estrelas obtidas, usando os dados reais.

**C. Mapa de campanha**

- Mapa vertical com ilhas, oceano, bases e pontos estratégicos.
- Rotas pontilhadas conectando as missões.
- Nós numerados para as fases.
- Estados visuais distintos para fases disponíveis, concluídas e bloqueadas.
- Chefes especiais destacados com ícone próprio.
- Possibilidade de rolar o mapa verticalmente para visualizar outras missões.

**D. Painel da missão selecionada**

Ao tocar em uma missão, apresentar um painel inferior com:

- Número da missão.
- Nome da operação.
- Miniatura do cenário.
- Dificuldade.
- Tipo de inimigos, caso essa informação exista.
- Chefe da fase, quando aplicável.
- Recompensas reais da missão.
- Requisitos para desbloqueio, quando aplicável.

**E. Ação principal**

- Botão DECOLAR.
- Deve iniciar a missão selecionada, respeitando as regras de desbloqueio atuais.

### Diretriz visual

O mapa deve parecer uma campanha militar de arcade, e não uma tabela ou grade de botões. As rotas devem ser claras e os nós precisam ser grandes o suficiente para toque.

---

## 8. Tela 4 — Oficina de fusão

### Objetivo

Deixar a fusão visualmente compreensível e atraente, sem mudar as regras, custos ou resultados já programados.

### Organização de cima para baixo

**A. Cabeçalho**

- Botão voltar.
- Título OFICINA DE FUSÃO.
- Recursos do jogador.

**B. Seleção das aeronaves**

- Área para a aeronave principal.
- Área para a aeronave catalisadora.
- Miniatura ou sprite de cada aeronave.
- Nome, nível e estrelas.
- Seletores conectados às opções reais do inventário.

**C. Apresentação do resultado**

- Mostrar a aeronave resultante quando a combinação for válida e o sistema atual permitir prever o resultado.
- Usar efeito visual de energia ou fusão.
- Não antecipar resultado quando a regra do jogo não permitir calculá-lo.

**D. Comparação de atributos**

- Comparar valores atuais e valores resultantes, somente quando esses dados forem calculáveis com as regras existentes.
- Destacar aumentos e reduções com cores e indicadores claros.

**E. Ação principal**

- Botão EXECUTAR FUSÃO.
- Respeitar custos, validações, consumo de aeronaves e regras atuais.
- Exibir confirmação ou retorno visual de sucesso/erro conforme o comportamento existente.

Eliminar espaços vazios desnecessários e organizar os elementos verticalmente.

---

## 9. Uso dos sprites e recursos gráficos

Usar as artes de aeronaves já disponibilizadas no projeto, quando estiverem presentes.

Regras:

- Preferir arquivos PNG individuais com transparência real.
- Preservar a proporção e a silhueta de cada aeronave.
- Evitar esticar, achatar ou cortar asas, caudas e motores.
- Não apresentar uma spritesheet completa dentro de um card.
- Não usar imagem com fundo escuro como se fosse transparente.
- Se os sprites ainda estiverem agrupados, identificar a necessidade de recorte e preparar uma estrutura organizada de assets.
- Manter nomes de arquivos consistentes e fáceis de localizar.
- Usar imagens de fundo separadas dos sprites das aeronaves.
- Não substituir sprites existentes sem necessidade.

Sugestão de organização, adaptando à estrutura real do projeto:

```text
assets/
  aircraft/
    fighters/
    wwii/
    bombers/
    helicopters/
    brazilian/
    american/
    russian/
    futuristic/
    bosses/
  backgrounds/
    hangar/
    campaign/
    menu/
  effects/
    explosions/
    projectiles/
    engine-trails/
  icons/
  ui/
```

Não mover arquivos existentes sem verificar antes todas as referências que os utilizam.

---

## 10. Animações e efeitos

Usar animações com moderação, mantendo o desempenho em celulares comuns.

Possibilidades:

- Brilho suave dos motores.
- Movimento sutil da aeronave no menu.
- Transições entre telas.
- Destaque de seleção no hangar.
- Brilho em missões disponíveis.
- Animação de conexão entre as aeronaves na fusão.
- Pequenos efeitos de recompensa e desbloqueio.

Evitar efeitos pesados, partículas excessivas e animações contínuas que prejudiquem a bateria ou a taxa de quadros.

Respeitar a preferência de redução de movimento do dispositivo quando a tecnologia utilizada permitir.

---

## 11. Organização técnica e qualidade

- Reutilizar componentes e funções atuais.
- Separar os componentes visuais por tela e responsabilidade.
- Evitar duplicação de lógica.
- Não misturar regras de economia ou progressão com código puramente visual.
- Manter o salvamento e a leitura dos dados existentes.
- Não adicionar dependências grandes sem necessidade.
- Não comprometer o funcionamento offline, caso o jogo já ofereça esse recurso.
- Não alterar a lógica de combate durante esta etapa.
- Manter compatibilidade com a tecnologia e as versões já usadas no projeto.

Se houver necessidade de alterar a estrutura de dados, explicar primeiro a necessidade e propor uma migração que preserve os dados existentes. Não apagar nem reinicializar o progresso do jogador.

---

## 12. Ordem de implementação

Executar o redesign em etapas pequenas. Ao terminar cada etapa, verificar o funcionamento antes de avançar.

### Etapa 1 — Auditoria e preparação

- Inspecionar o projeto.
- Identificar telas e componentes atuais.
- Mapear funções e dados que precisam ser preservados.
- Identificar os sprites e recursos gráficos disponíveis.
- Registrar riscos de compatibilidade.

### Etapa 2 — Sistema visual mobile

- Definir paleta, tipografia, espaçamentos e painéis.
- Ajustar estrutura base e responsividade.
- Implementar cabeçalhos, botões, cards e navegação reutilizáveis.

### Etapa 3 — Menu principal

- Reformular o menu.
- Conferir recursos, aeronave equipada e navegação.
- Testar os botões e o fluxo de entrada na campanha.

### Etapa 4 — Hangar

- Reformular apresentação da aeronave.
- Implementar categorias e carrossel.
- Conferir seleção, equipamento e aprimoramento.

### Etapa 5 — Campanha

- Implementar mapa e estados das missões.
- Conferir seleção, bloqueios, recompensas e início da fase.

### Etapa 6 — Oficina de fusão

- Reformular seletores, prévia e comparação.
- Conferir custos, validações e resultado da fusão.

### Etapa 7 — Testes finais

- Testar em 360 × 800 px.
- Testar em 390 × 844 px.
- Testar em 430 × 932 px.
- Verificar áreas seguras, rolagem e orientação vertical.
- Conferir se nenhum texto, botão ou sprite ficou cortado.
- Testar todas as ações e confirmar que o progresso foi preservado.

---

## 13. Critérios de aceitação

O redesign só deve ser considerado concluído quando:

- [ ] As quatro telas estiverem adaptadas para celular.
- [ ] O layout não depender de dimensões de desktop.
- [ ] A aeronave for o elemento visual protagonista do menu e do hangar.
- [ ] O menu mantiver acesso às funções existentes.
- [ ] O hangar exibir corretamente as aeronaves e seus atributos reais.
- [ ] O equipamento e o aprimoramento continuarem funcionando.
- [ ] O mapa representar visualmente as missões e seus estados reais.
- [ ] A seleção de missão iniciar a fase correta.
- [ ] A fusão respeitar as regras e os dados existentes.
- [ ] Moedas, diamantes, inventário e progresso forem preservados.
- [ ] Não houver rolagem horizontal acidental.
- [ ] Não houver elementos cortados ou sobrepostos nas resoluções de teste.
- [ ] O jogo continuar funcionando após atualizar ou reabrir a aplicação.

---

## 14. Instrução final para a IA

Trate este documento como a especificação visual e funcional do redesign mobile do DARWIN WAR I.

**Não faça uma reconstrução cega.** Primeiro compreenda o projeto existente, depois implemente as mudanças por etapas, preservando todas as funcionalidades e os dados.

Use as imagens de referência fornecidas junto com este documento para orientar a composição visual. As imagens são referências de layout, não telas para copiar literalmente.

Ao concluir cada etapa, informe:

1. Quais arquivos foram alterados ou criados.
2. O que mudou visualmente.
3. Quais funcionalidades foram verificadas.
4. Quais problemas ainda existem.
5. Como testar a tela no celular.

O objetivo final é um jogo mobile arcade de combate aéreo com aparência polida, navegação intuitiva, aeronaves em destaque e identidade visual própria: **DARWIN WAR I**.
