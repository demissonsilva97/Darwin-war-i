# DARWIN WAR I — Asset Pack 01

10 aeronaves individuais, cada uma em sua própria pasta, com sprite PNG transparente e animações em quadros PNG separados.

## Aeronaves
1. Falcão P-51 — caça clássico
2. Tucano EMB-314 — ataque leve
3. Gripen E — caça multirole
4. Su-57 Felon — caça 5ª geração
5. F-22 Raptor — caça furtivo
6. B-2 Spirit — bombardeiro stealth
7. MiG-31 Foxhound — interceptor
8. Rafale — caça multirole
9. J-20 Mighty Dragon — caça furtivo
10. XF-01 Valkyrie — experimental fictícia

## Estrutura por aeronave
- `Sprites/aviao.png`: sprite principal 512×512, RGBA transparente.
- `Sprites/aviao_preview.png`: prévia reduzida.
- `Animacoes/Motor/`: 4 quadros em loop.
- `Animacoes/Tiro/`: 4 quadros.
- `Animacoes/Dano/`: 4 quadros.
- `Animacoes/Explosao/`: 6 quadros.
- `info.json`: metadados e caminhos.

Todos os aviões estão em vista superior, com o nariz apontando para cima. Os quadros são arquivos PNG independentes, nomeados `frame_01.png`, `frame_02.png` etc. Configure a velocidade de reprodução no motor do jogo.

Nota: artes estilizadas originais para o jogo, inspiradas em silhuetas conhecidas, não desenhos técnicos exatos. Revise escala, pivô e colisores antes de integrar.
