Add-Type -AssemblyName System.Drawing

$root = Split-Path -Parent $PSScriptRoot
$sourcePath = Join-Path $root 'Artes prontas, criadas com CHATGPT\Atlas de Aeronaves Pixel Art.png'
$outputDir = Join-Path $root 'assets\aircraft\darwin'
New-Item -ItemType Directory -Force -Path $outputDir | Out-Null

$atlas = [System.Drawing.Bitmap]::new($sourcePath)
try {
    # O atlas é organizado em 10 colunas por 6 linhas, sem texto. Cada célula
    # é isolada, tem o fundo escuro removido e é centralizada numa tela 192².
    $cols = 10; $rows = 6; $canvasSize = 192
    $cellW = $atlas.Width / $cols
    # As seis fileiras têm espaçamento levemente irregular no atlas.
    $rowBounds = @(0, 165, 325, 475, 625, 775, $atlas.Height)

    for ($row = 0; $row -lt $rows; $row++) {
        for ($col = 0; $col -lt $cols; $col++) {
            $left = [int][Math]::Round($col * $cellW) + 12
            $top = $rowBounds[$row]
            $right = [int][Math]::Round(($col + 1) * $cellW) - 12
            $bottom = $rowBounds[$row + 1]
            $width = $right - $left; $height = $bottom - $top
            $cut = [System.Drawing.Bitmap]::new($width, $height, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)

            $minX = $width; $minY = $height; $maxX = -1; $maxY = -1
            for ($y = 0; $y -lt $height; $y++) {
                for ($x = 0; $x -lt $width; $x++) {
                    $color = $atlas.GetPixel($left + $x, $top + $y)
                    $max = [Math]::Max($color.R, [Math]::Max($color.G, $color.B))
                    $min = [Math]::Min($color.R, [Math]::Min($color.G, $color.B))
                    $luma = (0.2126 * $color.R) + (0.7152 * $color.G) + (0.0722 * $color.B)
                    $chroma = $max - $min
                    # Preserva metal claro e detalhes coloridos; remove o gradiente preto do atlas.
                    $signal = [Math]::Max(($luma - 59) * 7.2, ($chroma - 25) * 5.4)
                    $alpha = [int][Math]::Max(0, [Math]::Min(255, $signal))
                    if ($alpha -lt 16) { $alpha = 0 }
                    # Elimina vazamentos de uma célula vizinha no limite do atlas.
                    if ($x -lt 8 -or $x -ge ($width - 8) -or $y -lt 5 -or $y -ge ($height - 5)) { $alpha = 0 }
                    $cut.SetPixel($x, $y, [System.Drawing.Color]::FromArgb($alpha, $color.R, $color.G, $color.B))
                    if ($alpha -gt 28) {
                        if ($x -lt $minX) { $minX = $x }; if ($y -lt $minY) { $minY = $y }
                        if ($x -gt $maxX) { $maxX = $x }; if ($y -gt $maxY) { $maxY = $y }
                    }
                }
            }

            $output = [System.Drawing.Bitmap]::new($canvasSize, $canvasSize, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
            if ($maxX -ge $minX -and $maxY -ge $minY) {
                $minX = [Math]::Max(0, $minX - 3); $minY = [Math]::Max(0, $minY - 3)
                $maxX = [Math]::Min($width - 1, $maxX + 3); $maxY = [Math]::Min($height - 1, $maxY + 3)
                $sourceRect = [System.Drawing.Rectangle]::FromLTRB($minX, $minY, $maxX + 1, $maxY + 1)
                $scale = [Math]::Min(170 / $sourceRect.Width, 170 / $sourceRect.Height)
                $drawW = [int][Math]::Round($sourceRect.Width * $scale); $drawH = [int][Math]::Round($sourceRect.Height * $scale)
                $drawX = [int][Math]::Round(($canvasSize - $drawW) / 2); $drawY = [int][Math]::Round(($canvasSize - $drawH) / 2)
                $graphics = [System.Drawing.Graphics]::FromImage($output)
                try {
                    $graphics.Clear([System.Drawing.Color]::Transparent)
                    $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                    $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
                    $destinationRect = [System.Drawing.Rectangle]::new($drawX, $drawY, $drawW, $drawH)
                    $graphics.DrawImage($cut, $destinationRect, $sourceRect, [System.Drawing.GraphicsUnit]::Pixel)
                } finally { $graphics.Dispose() }
            }
            $id = ($row * $cols) + $col + 1
            $output.Save((Join-Path $outputDir ("dw_{0:d2}.png" -f $id)), [System.Drawing.Imaging.ImageFormat]::Png)
            $cut.Dispose(); $output.Dispose()
        }
    }
} finally {
    $atlas.Dispose()
}
