// Motor Gráfico de Alta Definição com suporte a Sprites Vetoriais e Canvas para Darwin War I
// Integração dos 10 Modelos de Alta Fidelidade no estilo arcade militar

class SpriteRenderer {
    constructor() {
        this.rotorAngle = 0;
        this.propellerAngle = 0;
        this.glowPhase = 0;

        // Cache de sprites Darwin War I extraídos dos atlas autorais.
        this.loadedSprites = {};
        this.loadedCards = {};
        this.loadedEffects = {};
        this.spriteMap = {};
        this.cardMap = {};
        // A frota jogável usa somente os PNGs oficiais do pacote Darwin War I.
        PLANES_DATA.forEach((plane) => {
            const base = `assets/Darwin_War_I_Assets_Pack_01/Aeronaves/${plane.assetFolder}`;
            this.spriteMap[plane.id] = `${base}/Sprites/aviao.png`;
            this.cardMap[plane.id] = `${base}/Sprites/aviao_preview.png`;
            this.loadedEffects[plane.id] = {};
            ['Motor', 'Tiro', 'Dano', 'Explosao'].forEach(effect => {
                const total = effect === 'Explosao' ? 6 : 4;
                this.loadedEffects[plane.id][effect] = Array.from({ length: total }, (_, index) => {
                    const image = new Image();
                    image.src = `${base}/Animacoes/${effect}/frame_${String(index + 1).padStart(2, '0')}.png`;
                    return image;
                });
            });
        });
        WINGMEN_DATA.forEach((wingman, index) => {
            const number = String(56 + (index % 5)).padStart(2, '0');
            this.spriteMap[wingman.id] = `assets/aircraft/darwin/dw_${number}.png`;
        });
        // Artes legadas continuam disponíveis somente para inimigos e chefes.
        Object.assign(this.spriteMap, {
            spitfire_mk: 'assets/sprites/plane_9_corsair.svg',
            zero_sen: 'assets/sprites/plane_8_aeropass.svg',
            bf109_gustav: 'assets/sprites/plane_3_terminator.svg',
            corsair_f4u: 'assets/sprites/plane_9_corsair.svg',
            j15_flying_shark: 'assets/sprites/plane_7_j20.svg',
            ah64_apache: 'assets/sprites/plane_6_apache.svg',
            ah1_cobra: 'assets/sprites/plane_6_apache.svg',
            mi24_hind: 'assets/sprites/plane_6_apache.svg',
            b17_fortress: 'assets/sprites/plane_2_b2.svg',
            xb3_titan: 'assets/sprites/plane_10_roswell.svg',
            alien_mothership: 'assets/sprites/plane_10_roswell.svg'
        });
        this.preloadSprites();
    }

    preloadSprites() {
        Object.entries(this.spriteMap).forEach(([id, path]) => {
            const img = new Image();
            img.src = path;
            img.onload = () => {
                this.loadedSprites[id] = img;
            };
        });

        Object.entries(this.cardMap).forEach(([id, path]) => {
            const img = new Image();
            img.src = path;
            img.onload = () => {
                this.loadedCards[id] = img;
            };
        });
    }

    getCardImage(planeId) {
        return this.loadedCards[planeId] || null;
    }

    getSpriteImage(planeData) {
        if (!planeData) return null;
        if (this.loadedSprites[planeData.id]) {
            return this.loadedSprites[planeData.id];
        }
        // Inimigos e chefes também usam o mesmo conjunto de artes, escolhido
        // de forma estável pela sua classe, em vez de cair em desenho genérico.
        const loadedIds = Object.keys(this.loadedSprites);
        if (!loadedIds.length) return null;
        const key = String(planeData.id || planeData.nome || planeData.type || planeData.forma || 'enemy');
        const hash = [...key].reduce((sum, char) => ((sum * 31) + char.charCodeAt(0)) >>> 0, 7);
        return this.loadedSprites[loadedIds[hash % loadedIds.length]] || null;
    }

    drawEffect(ctx, planeData, effect, x, y, size, frame = 0, alpha = 1) {
        const frames = planeData && this.loadedEffects[planeData.id] && this.loadedEffects[planeData.id][effect];
        const image = frames && frames[frame % frames.length];
        if (!image || !image.complete || !image.naturalWidth) return;
        const ratio = image.naturalWidth / image.naturalHeight || 1;
        const width = ratio >= 1 ? size : size * ratio;
        const height = ratio >= 1 ? size / ratio : size;
        ctx.save();
        ctx.globalAlpha = alpha;
        ctx.drawImage(image, x - width / 2, y - height / 2, width, height);
        ctx.restore();
    }

    update(dt = 0.016) {
        this.rotorAngle = (this.rotorAngle + dt * 25) % (Math.PI * 2);
        this.propellerAngle = (this.propellerAngle + dt * 35) % (Math.PI * 2);
        this.glowPhase = (this.glowPhase + dt * 4) % (Math.PI * 2);
    }

    // Desenha a nave com sprite SVG de alta definição ou fallback procedural
    drawPlane(ctx, planeData, x, y, size = 64, tilt = 0, isPlayer = true, level = 1) {
        ctx.save();
        ctx.translate(x, y);

        // Inclinação lateral dinâmica (banking)
        ctx.scale(1 - Math.abs(tilt) * 0.15, 1);
        ctx.rotate(tilt * 0.18);

        // Sombra realista na água
        if (isPlayer) {
            ctx.save();
            ctx.translate(16, 24);
            ctx.fillStyle = "rgba(0, 15, 35, 0.45)";
            this.renderPlaneSilhouette(ctx, planeData.forma, size * 0.95);
            ctx.restore();
        }

        const spriteImg = this.getSpriteImage(planeData);
        const isHelicopter = planeData.categoria === 'helicopteros' || String(planeData.forma || '').includes('helicoptero');

        // O efeito de motor oficial é desenhado antes da fuselagem, atrás da aeronave.
        if (isPlayer && planeData.assetFolder) {
            this.drawEffect(ctx, planeData, 'Motor', 0, size * 0.34, size * 0.9, Math.floor(Date.now() / 90));
        } else if (!isHelicopter) {
            this.renderPropulsion(ctx, planeData, size);
        }

        if (spriteImg && spriteImg.complete && spriteImg.naturalWidth > 0) {
            // Desenhar sprite artístico importado
            const spriteRatio = spriteImg.naturalWidth / spriteImg.naturalHeight || 1;
            const maxSize = size * 1.25;
            const drawW = spriteRatio >= 1 ? maxSize : maxSize * spriteRatio;
            const drawH = spriteRatio >= 1 ? maxSize / spriteRatio : maxSize;
            ctx.drawImage(spriteImg, -drawW / 2, -drawH / 2, drawW, drawH);

        } else {
            // Fallback procedural de alta resolução
            this.renderPlaneBody(ctx, planeData, size);
        }

        if (isHelicopter) this.renderRotor(ctx, size);

        // Borda dourada de evolução de nível
        if (level > 1) {
            ctx.strokeStyle = `rgba(245, 158, 11, ${0.4 + 0.3 * Math.sin(this.glowPhase)})`;
            ctx.lineWidth = 2.5;
            ctx.strokeRect(-size * 0.55, -size * 0.55, size * 1.1, size * 1.1);
        }

        ctx.restore();
    }

    renderPlaneSilhouette(ctx, forma, size) {
        ctx.beginPath();
        if (forma === "flying_wing_b2") {
            ctx.moveTo(0, -size * 0.4);
            ctx.lineTo(size * 0.9, size * 0.35);
            ctx.lineTo(size * 0.65, size * 0.45);
            ctx.lineTo(size * 0.45, size * 0.3);
            ctx.lineTo(0, size * 0.4);
            ctx.lineTo(-size * 0.45, size * 0.3);
            ctx.lineTo(-size * 0.65, size * 0.45);
            ctx.lineTo(-size * 0.9, size * 0.35);
        } else if (forma === "disco_alien") {
            ctx.arc(0, 0, size * 0.45, 0, Math.PI * 2);
        } else {
            ctx.ellipse(0, 0, size * 0.18, size * 0.45, 0, 0, Math.PI * 2);
            ctx.ellipse(0, -size * 0.05, size * 0.55, size * 0.12, 0, 0, Math.PI * 2);
        }
        ctx.closePath();
        ctx.fill();
    }

    renderPlaneBody(ctx, data, size) {
        const primary = data.corPrincipal || "#334155";
        const secondary = data.corSecundaria || "#38bdf8";

        ctx.save();
        // Asas
        ctx.fillStyle = primary;
        ctx.beginPath();
        ctx.ellipse(0, -size * 0.05, size * 0.55, size * 0.14, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#0f172a";
        ctx.lineWidth = 2;
        ctx.stroke();

        // Fuselagem
        ctx.fillStyle = primary;
        ctx.beginPath();
        ctx.ellipse(0, 0, size * 0.14, size * 0.46, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Cockpit
        ctx.fillStyle = "rgba(56, 189, 248, 0.9)";
        ctx.beginPath();
        ctx.ellipse(0, -size * 0.12, size * 0.08, size * 0.16, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = 1;
        ctx.stroke();

        // Cauda
        ctx.fillStyle = secondary;
        ctx.fillRect(-size * 0.22, size * 0.32, size * 0.44, size * 0.06);

        ctx.restore();
    }

    renderPropulsion(ctx, data, size) {
        const forma = data.forma || "";
        const isClassic = data.categoria === 'classicos' || /monoplano|biplano|stuka|corsair|wwii/i.test(forma);
        const isJet = !isClassic && (forma.includes("jato") || forma.includes("stealth") || forma.includes("delta") || forma.includes("canard") || data.tier >= 3);

        if (isJet) {
            ctx.save();
            const flameLen = size * (0.34 + 0.12 * (0.5 + 0.5 * Math.sin(this.glowPhase * 2.4)));
            const grad = ctx.createLinearGradient(0, size * 0.4, 0, size * 0.4 + flameLen);
            grad.addColorStop(0, "rgba(255, 255, 255, 0.95)");
            grad.addColorStop(0.3, "rgba(56, 189, 248, 0.9)");
            grad.addColorStop(0.7, "rgba(249, 115, 22, 0.8)");
            grad.addColorStop(1, "rgba(239, 68, 68, 0)");

            [-0.08, 0.08].forEach(offset => {
                ctx.fillStyle = grad;
                ctx.beginPath();
                ctx.moveTo(offset * size - size * 0.045, size * 0.30);
                ctx.lineTo(offset * size + size * 0.045, size * 0.30);
                ctx.lineTo(offset * size, size * 0.30 + flameLen);
                ctx.closePath();
                ctx.fill();
            });
            ctx.restore();
        } else if (isClassic) {
            // Hélice translúcida, girando de verdade no loop do Canvas.
            ctx.save();
            ctx.rotate(this.propellerAngle);
            ctx.fillStyle = 'rgba(205, 230, 245, 0.24)';
            ctx.fillRect(-size * 0.035, -size * 0.58, size * 0.07, size * 1.16);
            ctx.rotate(Math.PI / 2);
            ctx.fillRect(-size * 0.028, -size * 0.48, size * 0.056, size * 0.96);
            ctx.restore();
        }
    }

    renderRotor(ctx, size) {
        ctx.save();
        ctx.translate(0, -size * 0.24);
        ctx.rotate(this.rotorAngle);
        ctx.strokeStyle = 'rgba(215, 240, 255, 0.48)';
        ctx.lineWidth = Math.max(1.5, size * 0.025);
        [-1, 1].forEach(direction => {
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(direction * size * 0.88, 0);
            ctx.stroke();
        });
        ctx.fillStyle = 'rgba(220, 245, 255, 0.72)';
        ctx.beginPath(); ctx.arc(0, 0, size * 0.055, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
    }

    // Wingman
    drawWingman(ctx, wingData, x, y, size = 28) {
        ctx.save();
        ctx.translate(x, y);

        // Sombra
        ctx.fillStyle = "rgba(0,0,0,0.35)";
        ctx.beginPath();
        ctx.ellipse(8, 12, size * 0.4, size * 0.3, 0, 0, Math.PI * 2);
        ctx.fill();

        const sprite = this.getSpriteImage(wingData);
        if (sprite && sprite.complete && sprite.naturalWidth > 0) {
            const drawSize = size * 1.55;
            ctx.drawImage(sprite, -drawSize / 2, -drawSize / 2, drawSize, drawSize);
            this.renderPropulsion(ctx, { tier: wingData.tier || 1, forma: 'jato' }, size);
            ctx.restore();
            return;
        }

        // Fallback apenas durante o carregamento da arte.
        ctx.fillStyle = wingData.cor || "#38bdf8";
        ctx.beginPath();
        ctx.moveTo(0, -size * 0.55);
        ctx.lineTo(size * 0.55, size * 0.4);
        ctx.lineTo(0, size * 0.2);
        ctx.lineTo(-size * 0.55, size * 0.4);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "#0f172a";
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Pós-combustor do drone
        ctx.fillStyle = "#f59e0b";
        ctx.fillRect(-size * 0.1, size * 0.25, size * 0.2, size * 0.25);

        ctx.restore();
    }

    // Navio de Guerra (Encouraçado)
    drawWarship(ctx, x, y, width, height, turrets = [], healthPct = 1) {
        ctx.save();
        ctx.translate(x, y);

        // Esteira d'água
        ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
        ctx.beginPath();
        ctx.ellipse(0, height * 0.55, width * 0.6, height * 0.15, 0, 0, Math.PI * 2);
        ctx.fill();

        // Casco
        ctx.fillStyle = "#334155";
        ctx.beginPath();
        ctx.moveTo(0, -height * 0.5);
        ctx.lineTo(width * 0.5, -height * 0.3);
        ctx.lineTo(width * 0.45, height * 0.45);
        ctx.lineTo(-width * 0.45, height * 0.45);
        ctx.lineTo(-width * 0.5, -height * 0.3);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "#1e293b";
        ctx.lineWidth = 3;
        ctx.stroke();

        // Convés
        ctx.fillStyle = "#475569";
        ctx.fillRect(-width * 0.35, -height * 0.25, width * 0.7, height * 0.65);

        // Ponte de comando
        ctx.fillStyle = "#1e293b";
        ctx.fillRect(-width * 0.2, -height * 0.05, width * 0.4, height * 0.25);

        // Torres de artilharia
        turrets.forEach(turret => {
            ctx.save();
            ctx.translate(turret.x, turret.y);
            ctx.rotate(turret.angle || 0);

            // Canos duplos
            ctx.fillStyle = "#0f172a";
            ctx.fillRect(-4, -18, 3, 18);
            ctx.fillRect(1, -18, 3, 18);

            // Torre
            ctx.fillStyle = "#64748b";
            ctx.beginPath();
            ctx.arc(0, 0, 9, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = "#000";
            ctx.stroke();

            ctx.restore();
        });

        // Barra de HP
        if (healthPct < 1) {
            ctx.fillStyle = "rgba(0,0,0,0.6)";
            ctx.fillRect(-width * 0.4, -height * 0.55, width * 0.8, 6);
            ctx.fillStyle = healthPct > 0.3 ? "#22c55e" : "#ef4444";
            ctx.fillRect(-width * 0.4, -height * 0.55, width * 0.8 * healthPct, 6);
        }

        ctx.restore();
    }
}

window.spriteRenderer = new SpriteRenderer();
