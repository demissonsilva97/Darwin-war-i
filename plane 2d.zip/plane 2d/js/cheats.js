// Terminal de Cheats & Códigos Militares Secretos para Darwin War I

class CheatSystem {
    constructor() {
        this.history = [];
    }

    executeCommand(cmd) {
        if (!cmd) return { success: false, msg: "Digite um comando válido." };
        const clean = cmd.trim().toUpperCase();
        window.sounds.init();

        let response = { success: true, msg: "" };

        switch (clean) {
            case "OURO":
            case "GOLD":
            case "MOREGOLD":
            case "PIX":
            case "DINHEIRO":
                window.saveManager.addCoins(100000);
                window.sounds.playCoin();
                response.msg = "AUTORIZADO: Depósito de +100.000 Moedas de Ouro realizado com sucesso!";
                break;

            case "DIAMANTE":
            case "DIAMANTES":
            case "DIAMONDS":
            case "GEMAS":
            case "PREMIUM":
                window.saveManager.addDiamonds(500);
                window.sounds.playDiamond();
                response.msg = "AUTORIZADO: Carga Premium de +500 Diamantes adicionada ao cofre!";
                break;

            case "IMUNE":
            case "GODMODE":
            case "INVENCIVEL":
            case "ESCUDO":
                window.saveManager.data.cheats.godmode = !window.saveManager.data.cheats.godmode;
                window.saveManager.save();
                window.sounds.playPowerUp();
                response.msg = window.saveManager.data.cheats.godmode 
                    ? "DEFESA SUPREMA ATIVADA: Modo Deus / Invulnerabilidade LIGADO!" 
                    : "DEFESA SUPREMA DESATIVADA: Modo Deus DESLIGADO!";
                break;

            case "TODASNAVES":
            case "ALLPLANES":
            case "HANGAR":
            case "DESBLOQUEAR":
                PLANES_DATA.forEach(p => {
                    if (!window.saveManager.data.navesPossuidas.includes(p.id)) {
                        window.saveManager.data.navesPossuidas.push(p.id);
                        window.saveManager.data.niveisNaves[p.id] = 1;
                    }
                });
                WINGMEN_DATA.forEach(w => {
                    if (!window.saveManager.data.wingmenPossuidos.includes(w.id)) {
                        window.saveManager.data.wingmenPossuidos.push(w.id);
                    }
                });
                window.saveManager.save();
                window.sounds.playFusion();
                response.msg = "FROTA COMPLETA: As 10 aeronaves oficiais e todos os wingmen foram liberados no Hangar!";
                break;

            case "FASES":
            case "ALLSTAGES":
            case "UNLOCKALL":
            case "100FASES":
                window.saveManager.data.maxFaseLiberada = 100;
                window.saveManager.save();
                window.sounds.playPowerUp();
                response.msg = "MAPA TÁTICO LIBERADO: Todas as 100 fases do Oceano Pacífico estão acessíveis!";
                break;

            case "MEGADANO":
            case "SUPERDAMAGE":
            case "ONESHOT":
                window.saveManager.data.cheats.superDamage = !window.saveManager.data.cheats.superDamage;
                window.saveManager.save();
                window.sounds.playShoot('heavy');
                response.msg = window.saveManager.data.cheats.superDamage
                    ? "POTÊNCIA MÁXIMA: Dano das armas multiplicado em 10X!"
                    : "POTÊNCIA PADRÃO: Dano normal restaurado.";
                break;

            case "ESPECIAL":
            case "BOMBAS":
            case "INFINITE":
                window.saveManager.data.cheats.infiniteSpecial = !window.saveManager.data.cheats.infiniteSpecial;
                window.saveManager.save();
                window.sounds.playBomb();
                response.msg = window.saveManager.data.cheats.infiniteSpecial
                    ? "SUPRIMENTO NUCLEAR: Especiais e Bombas infinitas ativados!"
                    : "SUPRIMENTO PADRÃO: Especiais limitados.";
                break;

            case "RESET":
            case "REINICIAR":
                window.saveManager.reset();
                response.msg = "DADOS REDEFINIDOS: Seu perfil voltou às configurações iniciais de fábrica.";
                break;

            case "AJUDA":
            case "HELP":
            case "COMANDOS":
                response.msg = "CÓDIGOS DISPONÍVEIS:\n- PIX ou OURO (+100k moedas)\n- DIAMANTES (+500 diamantes)\n- IMUNE (Invencibilidade)\n- TODASNAVES (Desbloqueia as 10 aeronaves oficiais)\n- FASES (Desbloqueia as 100 fases)\n- MEGADANO (Dano 10x)\n- ESPECIAL (Bombas infinitas)\n- RESET (Zerar progresso)";
                break;

            default:
                response.success = false;
                response.msg = `CÓDIGO NÃO RECONHECIDO: "${cmd}". Digite AJUDA para a lista de códigos.`;
                break;
        }

        return response;
    }
}

window.cheats = new CheatSystem();
