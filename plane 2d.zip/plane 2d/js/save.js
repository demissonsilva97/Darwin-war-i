// Sistema de Salvamento Automático e Persistência do Darwin War I
const SAVE_KEY = "SKYFORCE_1945_DATA_V1";

class SaveManager {
    constructor() {
        this.data = this.getDefaults();
        this.load();
    }

    getDefaults() {
        return {
            moedas: 500, // Moedas iniciais de incentivo
            diamantes: 5, // Diamantes iniciais
            maxFaseLiberada: 1, // Começa na fase 1 de 100
            faseAtual: 1,
            estrelasFase: {}, // { 1: { estrelas: 3, noDamage: true, score: 5000 } }
            navesPossuidas: ["DW_001"],
            niveisNaves: { "DW_001": 1 },
            naveEquipada: "DW_001",
            wingmanEsquerdo: "wing_mini_p51",
            wingmanDireito: null,
            wingmenPossuidos: ["wing_mini_p51"],
            fusaoHistorico: [],
            cheats: {
                godmode: false,
                superDamage: false,
                infiniteSpecial: false
            },
            stats: {
                totalInimigosAbatidos: 0,
                totalDanoCausado: 0,
                totalFasesSemDano: 0
            }
        };
    }

    load() {
        try {
            const raw = localStorage.getItem(SAVE_KEY);
            if (raw) {
                const parsed = JSON.parse(raw);
                this.data = { ...this.getDefaults(), ...parsed };
                this.migrateFleet();
            }
        } catch (e) {
            console.warn("Erro ao carregar dados salvos:", e);
            this.data = this.getDefaults();
        }
    }

    // Perfis anteriores nunca podem reintroduzir aeronaves legadas no hangar.
    migrateFleet() {
        const validIds = new Set(PLAYER_AIRCRAFT.map(plane => plane.id));
        const legacyToOfficial = { p51_mustang: 'DW_001', t99_tucano: 'DW_002', g39_griphon: 'DW_003', j20_dragon: 'DW_009', mecha_valkyrie: 'DW_010' };
        const previousOwned = Array.isArray(this.data.navesPossuidas) ? this.data.navesPossuidas : [];
        const migrated = previousOwned.map(id => legacyToOfficial[id] || id).filter(id => validIds.has(id));
        this.data.navesPossuidas = [...new Set(migrated)];
        if (!this.data.navesPossuidas.length) this.data.navesPossuidas = ['DW_001'];
        const oldLevels = this.data.niveisNaves || {};
        this.data.niveisNaves = Object.fromEntries(this.data.navesPossuidas.map(id => [id, oldLevels[id] || oldLevels[Object.keys(legacyToOfficial).find(oldId => legacyToOfficial[oldId] === id)] || 1]));
        const equipped = legacyToOfficial[this.data.naveEquipada] || this.data.naveEquipada;
        this.data.naveEquipada = this.data.navesPossuidas.includes(equipped) ? equipped : this.data.navesPossuidas[0];
        this.save();
    }

    save() {
        try {
            localStorage.setItem(SAVE_KEY, JSON.stringify(this.data));
        } catch (e) {
            console.error("Falha ao salvar:", e);
        }
    }

    addCoins(amount) {
        this.data.moedas = Math.max(0, this.data.moedas + Math.round(amount));
        this.save();
    }

    addDiamonds(amount) {
        this.data.diamantes = Math.max(0, this.data.diamantes + Math.round(amount));
        this.save();
    }

    unlockPlane(id) {
        if (!PLAYER_AIRCRAFT.some(plane => plane.id === id)) return false;
        if (!this.data.navesPossuidas.includes(id)) {
            this.data.navesPossuidas.push(id);
            this.data.niveisNaves[id] = 1;
            this.save();
            return true;
        }
        return false;
    }

    equipPlane(id) {
        if (PLAYER_AIRCRAFT.some(plane => plane.id === id) && this.data.navesPossuidas.includes(id)) {
            this.data.naveEquipada = id;
            this.save();
            return true;
        }
        return false;
    }

    completeStage(faseNum, score, tookDamage) {
        const noDamage = !tookDamage;
        const estrelas = noDamage ? 3 : score > 2000 ? 2 : 1;

        if (!this.data.estrelasFase[faseNum] || estrelas > this.data.estrelasFase[faseNum].estrelas) {
            this.data.estrelasFase[faseNum] = {
                estrelas: estrelas,
                noDamage: noDamage,
                score: Math.max(score, this.data.estrelasFase[faseNum]?.score || 0)
            };
        }

        if (noDamage) {
            this.data.stats.totalFasesSemDano++;
            // Recompensa premium: 1 Diamante por passar sem dano!
            this.addDiamonds(1);
        }

        // Desbloquear próxima fase até o limite de 100
        if (faseNum >= this.data.maxFaseLiberada && faseNum < 100) {
            this.data.maxFaseLiberada = faseNum + 1;
        }

        this.save();
        return { estrelas, noDamage, diamondEarned: noDamage ? 1 : 0 };
    }

    reset() {
        this.data = this.getDefaults();
        this.save();
    }
}

window.saveManager = new SaveManager();
