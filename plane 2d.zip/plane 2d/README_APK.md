# 🛩️ SKY FORCE 1945: PACIFIC COMBAT

Jogo completo de tiro arcade estilo shoot 'em up (shmup) inspirado no lendário **1945 Air Force**.

---

## 🌟 Características Principais Implementadas

1. **Controles Fidedignos ao 1945 Air Force:**
   - Controle direto por arrasto do dedo na tela do celular com **offset vertical ergonômico** (o avião se posiciona levemente acima do dedo para você ter total visão dos tiros e projéteis inimigos).
   - Suporte híbrido a Teclado (`W, A, S, D` ou `Setas` + `Espaço` para Bomba Especial) e Mouse no PC.

2. **Cenário Pacífico Limpo & Náutico:**
   - Mar infinito com ondas dinâmicas e reflexos em alta performance, sem poluição visual.
   - Ilhas paradisíacas com recifes de corais e pistas militares de decolagem.

3. **Catálogo Gigantesco com +50 Aeronaves & Helicópteros:**
   - **Furtivos & Protótipos Ultracaros:** B2-Phantom "Espectro Noturno" (B-2 Spirit - 100 Diamantes), F-22 Raptor, SR-71 Blackbird, XB-70 Valkyrie.
   - **Aeronaves Brasileiras (Inspiradas na FAB & Embraer):** T-99 Guardião da Selva (Super Tucano), G-39 Griphon Milênio (Gripen), KC-390 Fortaleza dos Céus, EMB-145 Radar Erieye Sentinela, AMX Gavião, Bandeirante P-95.
   - **Comerciais Militarizados (Inspirados na LATAM / Linha Civil):** Aero-Latina 320 Gunship, Sky-Liner 777 Cruzador Aéreo, Jumbo 747 Rainha da Artilharia.
   - **Caças Asiáticos / Orientais:** J-22 Dragão Imperial (J-20 chinês), J-15 Tubarão dos Mares, Su-35 Siberian Flanker, Su-57 Felon Furtivo.
   - **Helicópteros com Rotores Animados:** AH-64 Apache, Víbora Cobra, Chinook de Rotor Duplo (Tandem), Mi-24 Hind, Ka-50 Tubarão Negro.
   - **Clássicos da 2ª Guerra:** P-51 Mustang (Inicial), Spitfire, Zero, BF-109, Corsair asa gaivota, P-38 raio duplo, B-17, B-24, B-29 Superfortress.
   - **Alienígenas & Futuristas:** Aurora TR-3B Triângulo Negro, Roswell Disco Cósmico, Ciber Fênix Solar, Ceifador do Vácuo, Mecha-Valkyrie.

4. **Naves Menores de Suporte (Wingmen):**
   - Mini Mustang, Drone Laser Fotônico, Pod de Micro-Mísseis Guiados, Orbe Protetor EMP, Micro-B2 Fantasma.

5. **Oficina de Fusão (Fusion Lab):**
   - Funda duas naves para subir de Nível (+25% de dano e vida por nível) e chance de despertar modelos lendários secretos de tiers superiores.

6. **Economia Exata Solicitada:**
   - **Moedas de Ouro:** Ganhas em tempo real a cada tiro que causa dano aos inimigos, moedas por abates e moedas físicas voando para coleta com ímã.
   - **Diamantes (Premium):** Ganhe 1 diamante a cada fase superada com bônus "No Damage" (sem receber nenhum dano).
   - **Soma Final de Moedas:** Tela de vitória estilo arcade com animação somando dano infligido, inimigos destruídos e bônus sem dano.

7. **100 Fases Jogáveis & Chefes Colossais:**
   - Mapa de 100 fases onde você pode ir e voltar livremente em qualquer fase conquistada.
   - Chefes navais gigantescos (Encouraçados Dreadnoughts com 4 torres de artilharia giratórias destrutíveis que miram no jogador), Porta-aviões e Naves-Mãe alienígenas.

8. **Chat Militar de Cheats no Menu:**
   - `PIX` ou `OURO` (+100.000 moedas)
   - `DIAMANTES` (+500 diamantes)
   - `IMUNE` ou `GODMODE` (Invencibilidade contra tiros)
   - `TODASNAVES` (Desbloqueia as 52+ aeronaves no Hangar)
   - `FASES` (Desbloqueia as 100 fases do mapa)
   - `MEGADANO` (Dano 10x multiplicado)
   - `ESPECIAL` (Bombas atômicas infinitas)
   - `RESET` (Zerar dados)

9. **Salvamento Automático:**
   - Todo o progresso, naves, wingmen, estrelas e moedas são salvos continuamente via LocalStorage.

---

## 📱 Como Jogar no Celular e Transformar em APK

### Método 1: Instalação Instantânea como App no Celular (PWA)
1. Abra o arquivo `index.html` no navegador do celular (Chrome no Android ou Safari no iOS).
2. Toque nos 3 pontinhos do menu do navegador e escolha **"Instalar aplicativo"** ou **"Adicionar à tela de início"**.
3. O jogo será instalado no seu celular com ícone próprio e abrirá em **tela cheia** como se fosse um APK nativo baixado da Play Store!

### Método 2: Gerar APK Nativo Instalável (.apk)
Você pode transformar esta pasta web em um arquivo APK instalável em menos de 2 minutos usando qualquer uma das opções gratuitas:
- **Website 2 APK Builder** (ferramenta para Windows em 1 clique: aponte para a pasta e clique em "Generate APK").
- **PWABuilder** (https://www.pwabuilder.com): Gere o pacote APK para Android pronto para instalar.
- **Capacitor / Cordova**: Execute `npx cap init` e compile com Android Studio.
