// Gerenciador de Interface de Usuário (UI) para DARWIN WAR I
class UIManager {
    constructor() {
        this.currentScreen = "screen-menu";
        this.selectedCategory = "all";
        this.hangarMode = "owned";
        this.animatingCoins = false;
        this.selectedPlaneId = null;
        this.selectedStage = 1;
        this.lastFrameTime = 0;
        this.frameAccumulator = 0;

        // Nomes dos capítulos do mapa de campanha (10 capítulos, 10 fases cada)
        this.chapterNames = [
            "Capítulo 1: Pacífico Sul",
            "Capítulo 2: Mar do Coral",
            "Capítulo 3: Ilhas Salomão",
            "Capítulo 4: Golfo de Leyte",
            "Capítulo 5: Iwo Jima",
            "Capítulo 6: Okinawa",
            "Capítulo 7: Mar da China",
            "Capítulo 8: Estreito de Malaca",
            "Capítulo 9: Baía de Tóquio",
            "Capítulo 10: Operação Final"
        ];

        // Cores de raridade por tier
        this.rarityColors = {
            1: "#94a3b8",  // Cinza (Comum)
            2: "#22c55e",  // Verde (Incomum)
            3: "#3b82f6",  // Azul (Raro)
            4: "#a855f7",  // Roxo (Épico)
            5: "#f59e0b",  // Dourado (Lendário)
            6: "#ef4444"   // Vermelho (Mítico)
        };
    }

    init() {
        this.bindEvents();
        this.bindBottomNav();
        this.updateTopBar();
        this.renderStageMap();
        this.renderHangar();
        this.renderMenuPlanePreview();
        this.setupGameCallbacks();

        // Iniciar loop de renderização do jogo
        const loop = (now) => {
            if (window.gameEngine.running && !window.gameEngine.paused) {
                // A física existente é orientada a frames. Executá-la uma vez
                // por repaint tornava o jogo duas vezes mais rápido em telas
                // de 120 Hz; este acumulador mantém a simulação em 60 Hz.
                const elapsed = Math.min(0.05, (now - this.lastFrameTime) / 1000 || 1 / 60);
                this.frameAccumulator += elapsed;
                while (this.frameAccumulator >= 1 / 60) {
                    window.gameEngine.update(1 / 60);
                    this.frameAccumulator -= 1 / 60;
                }
                window.gameEngine.render();
                this.updateInGameHUD();
            } else {
                this.frameAccumulator = 0;
            }
            this.lastFrameTime = now;
            requestAnimationFrame(loop);
        };
        requestAnimationFrame(loop);
    }

    // ======================== SCREEN NAVIGATION ========================

    showScreen(screenId) {
        document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
        const target = document.getElementById(screenId);
        if (target) {
            target.classList.add('active');
            // Animação de transição de entrada
            target.classList.add('entering');
            setTimeout(() => target.classList.remove('entering'), 350);
            this.currentScreen = screenId;
        }
        this.updateTopBar();
        this.updateBottomNavState(screenId);

        // Esconder a nav bar inferior durante jogo, vitória e game over
        const navBottom = document.getElementById('nav-bottom');
        if (navBottom) {
            const hideOnScreens = ['screen-game', 'screen-victory', 'screen-gameover'];
            navBottom.style.display = hideOnScreens.includes(screenId) ? 'none' : '';
        }

        // Esconder a top bar durante o jogo
        const topBar = document.getElementById('top-bar');
        if (topBar) {
            topBar.style.display = screenId === 'screen-game' ? 'none' : '';
        }

        if (screenId === "screen-stages") {
            this.renderStageMap();
        } else if (screenId === "screen-hangar") {
            this.renderHangar();
        } else if (screenId === "screen-fusion") {
            this.renderFusionScreen();
        } else if (screenId === "screen-menu") {
            this.renderMenuPlanePreview();
        }
    }

    // ======================== BOTTOM NAV BAR ========================

    bindBottomNav() {
        const navBottom = document.getElementById('nav-bottom');
        if (!navBottom) return;

        navBottom.querySelectorAll('[data-nav-target], [data-goto]').forEach(navItem => {
            navItem.addEventListener('click', () => {
                window.sounds.init();
                const target = navItem.getAttribute('data-nav-target') || navItem.getAttribute('data-goto');
                this.showScreen(target);
            });
        });
    }

    updateBottomNavState(screenId) {
        const navBottom = document.getElementById('nav-bottom');
        if (!navBottom) return;

        navBottom.querySelectorAll('[data-nav-target], [data-goto]').forEach(navItem => {
            const target = navItem.getAttribute('data-nav-target') || navItem.getAttribute('data-goto');
            if (target === screenId) {
                navItem.classList.add('active');
            } else {
                navItem.classList.remove('active');
            }
        });
    }

    // ======================== TOP BAR CURRENCIES ========================

    updateTopBar() {
        const goldEl = document.getElementById('top-gold');
        const diamEl = document.getElementById('top-diamonds');
        if (goldEl) goldEl.innerText = window.saveManager.data.moedas.toLocaleString();
        if (diamEl) diamEl.innerText = window.saveManager.data.diamantes.toLocaleString();
        document.querySelectorAll('.hdr-gold').forEach(el => el.innerText = window.saveManager.data.moedas.toLocaleString());
        document.querySelectorAll('.hdr-diamonds').forEach(el => el.innerText = window.saveManager.data.diamantes.toLocaleString());
    }

    // ======================== EVENT BINDING ========================

    bindEvents() {
        // Navegação via data-goto (botões inline)
        document.querySelectorAll('[data-goto]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const target = btn.getAttribute('data-goto');
                const hangarMode = btn.getAttribute('data-hangar-mode');
                if (target === 'screen-hangar' && hangarMode) this.hangarMode = hangarMode;
                window.sounds.init();
                this.showScreen(target);
            });
        });

        // Botão de Som
        const soundBtn = document.getElementById('btn-sound-toggle');
        if (soundBtn) {
            soundBtn.addEventListener('click', () => {
                window.sounds.init();
                const enabled = window.sounds.toggle();
                soundBtn.innerText = enabled ? "🔊" : "🔇";
            });
        }

        // Botão de Cheats
        const cheatBtn = document.getElementById('btn-open-cheats');
        if (cheatBtn) {
            cheatBtn.addEventListener('click', () => {
                window.sounds.init();
                this.showScreen('screen-cheats');
            });
        }

        // Envio do formulário de Cheats
        const cheatForm = document.getElementById('cheat-form');
        const cheatInput = document.getElementById('cheat-input');
        if (cheatForm && cheatInput) {
            cheatForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const cmd = cheatInput.value;
                if (!cmd) return;
                const res = window.cheats.executeCommand(cmd);
                this.appendCheatLog(cmd, res.msg, res.success);
                cheatInput.value = "";
                this.updateTopBar();
            });
        }

        // Atalhos de cheats rápidos (chips)
        document.querySelectorAll('.cheat-chip').forEach(chip => {
            chip.addEventListener('click', () => {
                const cmd = chip.getAttribute('data-cmd');
                const res = window.cheats.executeCommand(cmd);
                this.appendCheatLog(cmd, res.msg, res.success);
                this.updateTopBar();
            });
        });

        // Botão In-game Especial / Bomba
        const specialBtn = document.getElementById('hud-btn-special');
        if (specialBtn) {
            specialBtn.addEventListener('click', () => {
                window.gameEngine.triggerSpecial();
            });
        }

        // Botão In-game Pausa
        const pauseBtn = document.getElementById('hud-btn-pause');
        if (pauseBtn) {
            pauseBtn.addEventListener('click', () => {
                window.gameEngine.paused = !window.gameEngine.paused;
                pauseBtn.innerText = window.gameEngine.paused ? "▶ RETOMAR" : "⏸ PAUSA";
            });
        }
    }

    // ======================== CHEAT TERMINAL ========================

    appendCheatLog(cmd, msg, success) {
        const container = document.getElementById('cheat-messages');
        if (!container) return;
        const msgDiv = document.createElement('div');
        msgDiv.className = `cheat-msg ${success ? 'success' : 'error'}`;
        msgDiv.innerHTML = `<strong>> ${cmd}</strong><br/><span>${msg.replace(/\n/g, '<br/>')}</span>`;
        container.appendChild(msgDiv);
        container.scrollTop = container.scrollHeight;
    }

    // ======================== MENU PLANE PREVIEW ========================

    renderMenuPlanePreview() {
        const canvas = document.getElementById('menu-plane-canvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const currentId = window.saveManager.data.naveEquipada;
        const plane = PLANES_DATA.find(p => p.id === currentId) || PLANES_DATA[0];
        const lvl = window.saveManager.data.niveisNaves[plane.id] || 1;

        window.spriteRenderer.drawPlane(ctx, plane, canvas.width / 2, canvas.height / 2, 85, 0, false, lvl);

        const nameEl = document.getElementById('menu-plane-name');
        const statsEl = document.getElementById('menu-plane-stats');

        if (nameEl) {
            nameEl.innerText = `${plane.nome} (Nível ${lvl})`;
            nameEl.style.color = this.rarityColors[plane.tier] || '#e2e8f0';
        }

        if (statsEl) {
            const mult = 1 + (lvl - 1) * 0.25;
            const tierStars = "⭐".repeat(plane.tier);
            statsEl.innerHTML = `HP: ${Math.round(plane.hp * mult)} | Dano: ${Math.round(plane.dano * mult)} | <span style="color:${this.rarityColors[plane.tier] || '#e2e8f0'}">${tierStars}</span>`;
        }
    }

    // ======================== STAGE MAP (CAMPAIGN) ========================

    renderStageMap() {
        const container = document.getElementById('stage-map-grid');
        if (!container) return;
        container.innerHTML = "";

        const maxLiberada = window.saveManager.data.maxFaseLiberada || 1;
        const estrelasData = window.saveManager.data.estrelasFase || {};
        this.selectedStage = Math.min(maxLiberada, Math.max(1, this.selectedStage || window.saveManager.data.faseAtual || 1));

        // Atualizar display do capítulo atual
        const chapterIndex = Math.min(9, Math.floor((maxLiberada - 1) / 10));
        const chapterEl = document.getElementById('chapter-display');
        if (chapterEl) {
            chapterEl.innerText = this.chapterNames[chapterIndex];
        }

        let currentChapter = -1;

        for (let i = 1; i <= 100; i++) {
            const isUnlocked = i <= maxLiberada;
            const isBossStage = i % 5 === 0;
            const stageInfo = estrelasData[i];
            const starsCount = stageInfo ? stageInfo.estrelas : 0;
            const noDamage = stageInfo ? stageInfo.noDamage : false;

            // Inserir divisor de capítulo a cada 10 fases
            const chapterIdx = Math.floor((i - 1) / 10);
            if (chapterIdx !== currentChapter) {
                currentChapter = chapterIdx;
                const divider = document.createElement('div');
                divider.className = 'chapter-divider';
                divider.innerHTML = `<span>${this.chapterNames[chapterIdx]}</span>`;
                container.appendChild(divider);
            }

            const node = document.createElement('button');
            node.type = 'button';
            node.className = `stage-node ${isUnlocked ? 'unlocked' : 'locked'} ${isBossStage ? 'boss-stage' : ''}`;
            node.setAttribute('aria-label', `Missão ${i}${isBossStage ? ', chefe' : ''}${isUnlocked ? '' : ', bloqueada'}`);

            let starsHtml = "";
            if (isUnlocked) {
                starsHtml = `<div class="stars-row">${"★".repeat(starsCount)}${"☆".repeat(3 - starsCount)}</div>`;
                if (noDamage) {
                    starsHtml += `<div class="nodamage-badge" title="Passada Sem Receber Dano! (Ganhou Diamante)">💎 NO HIT</div>`;
                }
            }

            node.innerHTML = `
                <div class="stage-num">${i}</div>
                ${isBossStage ? '<div class="boss-tag">CHEFÃO</div>' : ''}
                ${starsHtml}
                ${!isUnlocked ? '<div class="lock-icon">🔒</div>' : ''}
            `;

            if (isUnlocked) {
                node.addEventListener('click', () => {
                    window.sounds.init();
                    this.selectedStage = i;
                    this.updateMissionCard();
                    container.querySelectorAll('.stage-node').forEach(item => item.classList.toggle('selected-stage', item === node));
                });
            }

            if (i === this.selectedStage) node.classList.add('selected-stage');

            container.appendChild(node);
        }

        this.updateMissionCard();

        // Rola automaticamente até a missão selecionada/desbloqueada
        setTimeout(() => {
            const selected = container.querySelector('.stage-node.selected-stage');
            if (selected) {
                selected.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }, 100);
    }

    updateMissionCard() {
        const card = document.getElementById('stage-mission-card');
        if (!card) return;
        const stage = this.selectedStage;
        const unlocked = stage <= (window.saveManager.data.maxFaseLiberada || 1);
        const boss = stage % 5 === 0;
        const chapter = this.chapterNames[Math.floor((stage - 1) / 10)];
        const status = unlocked ? (window.saveManager.data.estrelasFase?.[stage] ? 'MISSÃO CONCLUÍDA — pode repetir para melhorar a pontuação.' : 'MISSÃO DISPONÍVEL') : 'MISSÃO BLOQUEADA';
        card.innerHTML = `
            <div class="mission-card-status">${status}</div>
            <div class="mission-card-title">OPERAÇÃO ${String(stage).padStart(2, '0')}${boss ? ' · ALERTA DE CHEFE' : ''}</div>
            <div class="mission-card-meta">${chapter} · ${boss ? 'Inimigo principal: chefe da região' : 'Esquadrilhas inimigas e recursos durante a missão'}</div>
            <button class="mission-launch" ${unlocked ? '' : 'disabled'}>${unlocked ? '🛫 DECOLAR' : '🔒 BLOQUEADA'}</button>
        `;
        const launch = card.querySelector('.mission-launch');
        if (launch && unlocked) launch.addEventListener('click', () => this.startStage(stage));
    }

    startStage(stageNum) {
        window.saveManager.data.faseAtual = stageNum;
        window.saveManager.save();
        this.showScreen('screen-game');
        const gameCanvas = document.getElementById('game-canvas');
        window.gameEngine.init(gameCanvas);
        window.gameEngine.startStage(stageNum);
    }

    // ======================== HANGAR — REDESIGNED ========================

    renderHangar() {
        const gridContainer = document.getElementById('hangar-planes-list');
        if (!gridContainer) return;
        gridContainer.innerHTML = "";

        const owned = window.saveManager.data.navesPossuidas;
        const equipped = window.saveManager.data.naveEquipada;

        // "Meu Hangar" mostra somente a frota real do jogador. O mercado
        // mostra o catálogo completo para compra, sem misturar os dois fluxos.
        let planes = this.hangarMode === 'owned'
            ? PLANES_DATA.filter(p => owned.includes(p.id))
            : PLANES_DATA;
        if (this.selectedCategory !== "all") {
            planes = planes.filter(p => p.categoria === this.selectedCategory);
        }

        // Determinar qual avião será selecionado inicialmente
        // Priorizar: avião equipado > primeiro possuído > primeiro da lista
        let initialSelect = null;
        const equippedInList = planes.find(p => p.id === equipped);
        if (equippedInList) {
            initialSelect = equippedInList;
        } else {
            const firstOwned = planes.find(p => owned.includes(p.id));
            initialSelect = firstOwned || planes[0] || null;
        }

        // Renderizar grid de cards 3 colunas
        planes.forEach(plane => {
            const isOwned = owned.includes(plane.id);
            const isEquipped = equipped === plane.id;
            const lvl = window.saveManager.data.niveisNaves[plane.id] || 1;

            const card = document.createElement('div');
            card.className = `plane-card-mini ${isEquipped ? 'equipped' : ''} ${isOwned ? 'owned' : 'locked'}`;
            card.setAttribute('data-plane-id', plane.id);

            const cId = `canvas-grid-${plane.id}`;
            const tierStars = "⭐".repeat(plane.tier);
            const rarityColor = this.rarityColors[plane.tier] || '#94a3b8';

            let indicator = '';
            if (isEquipped) {
                indicator = '<div class="card-indicator equipped-indicator">✔ EQUIPADA</div>';
            } else if (!isOwned) {
                indicator = '<div class="card-indicator lock-indicator">🔒</div>';
            }

            card.innerHTML = `
                <div class="card-canvas-thumb">
                    <canvas id="${cId}" width="80" height="80"></canvas>
                </div>
                <div class="card-mini-name" style="color:${rarityColor}">${plane.nome}</div>
                <div class="card-mini-tier" style="color:${rarityColor}">${tierStars}</div>
                ${indicator}
            `;

            card.addEventListener('click', () => {
                // Remover seleção anterior
                gridContainer.querySelectorAll('.plane-card-mini').forEach(c => c.classList.remove('selected'));
                card.classList.add('selected');
                this.updateSelectedPlane(plane);
            });

            gridContainer.appendChild(card);

            // Renderiza sprite da nave no card miniatura
            setTimeout(() => {
                const cv = document.getElementById(cId);
                if (cv) {
                    const ctx = cv.getContext('2d');
                    window.spriteRenderer.drawPlane(ctx, plane, 40, 40, 42, 0, false, lvl);
                }
            }, 10);
        });

        // Filtros de Categoria (abas)
        document.querySelectorAll('.hangar-tab').forEach(tab => {
            // Remover listeners anteriores clonando o nó
            const newTab = tab.cloneNode(true);
            tab.parentNode.replaceChild(newTab, tab);

            newTab.addEventListener('click', () => {
                document.querySelectorAll('.hangar-tab').forEach(t => t.classList.remove('active'));
                newTab.classList.add('active');
                this.selectedCategory = newTab.getAttribute('data-cat');
                this.renderHangar();
            });
        });

        document.querySelectorAll('.hangar-mode').forEach(mode => {
            mode.onclick = () => {
                this.hangarMode = mode.getAttribute('data-hangar-mode');
                document.querySelectorAll('.hangar-mode').forEach(item => item.classList.toggle('active', item === mode));
                this.renderHangar();
            };
            mode.classList.toggle('active', mode.getAttribute('data-hangar-mode') === this.hangarMode);
        });

        // Auto-selecionar o avião inicial
        if (initialSelect) {
            this.updateSelectedPlane(initialSelect);
            // Marcar card como selecionado no grid
            const selectedCard = gridContainer.querySelector(`[data-plane-id="${initialSelect.id}"]`);
            if (selectedCard) {
                selectedCard.classList.add('selected');
            }
        }
    }

    updateSelectedPlane(planeData) {
        this.selectedPlaneId = planeData.id;
        const owned = window.saveManager.data.navesPossuidas;
        const equipped = window.saveManager.data.naveEquipada;
        const isOwned = owned.includes(planeData.id);
        const isEquipped = equipped === planeData.id;
        const lvl = window.saveManager.data.niveisNaves[planeData.id] || 1;
        const mult = 1 + (lvl - 1) * 0.25;
        const rarityColor = this.rarityColors[planeData.tier] || '#94a3b8';

        // Canvas grande da nave selecionada
        const canvas = document.getElementById('hangar-selected-canvas');
        if (canvas) {
            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            window.spriteRenderer.drawPlane(ctx, planeData, canvas.width / 2, canvas.height / 2, 85, 0, false, lvl);
        }

        // Nome da nave
        const nameEl = document.getElementById('hangar-selected-name');
        if (nameEl) {
            nameEl.innerText = `${planeData.nome} (Nível ${lvl})`;
            nameEl.style.color = rarityColor;
        }

        // Categoria
        const catEl = document.getElementById('hangar-selected-category');
        if (catEl) {
            catEl.innerText = this.getCategoryDisplayName(planeData.categoria);
        }

        // Estrelas de raridade
        const starsEl = document.getElementById('hangar-selected-rarity') || document.getElementById('hangar-selected-stars');
        if (starsEl) {
            starsEl.innerHTML = `<span style="color:${rarityColor}">${"⭐".repeat(planeData.tier)}</span>`;
        }

        // Stats completos
        const statsEl = document.getElementById('hangar-stats-panel') || document.getElementById('hangar-selected-stats');
        if (statsEl) {
            statsEl.innerHTML = `
                <div class="stat-row"><span class="stat-label">HP</span><span class="stat-value">${Math.round(planeData.hp * mult)}</span></div>
                <div class="stat-row"><span class="stat-label">Dano</span><span class="stat-value">${Math.round(planeData.dano * mult)}</span></div>
                <div class="stat-row"><span class="stat-label">Cadência</span><span class="stat-value">${planeData.cadencia}ms</span></div>
                <div class="stat-row"><span class="stat-label">Velocidade</span><span class="stat-value">${planeData.velocidade}</span></div>
                <div class="stat-row"><span class="stat-label">Defesa</span><span class="stat-value">${planeData.defesa || 0}</span></div>
                <div class="stat-row"><span class="stat-label">Especial</span><span class="stat-value">${planeData.especial}</span></div>
            `;
        }

        // Descrição
        const descEl = document.getElementById('hangar-selected-desc');
        if (descEl) {
            descEl.innerText = planeData.descricao || '';
        }

        // Botões de ação
        const actionsEl = document.getElementById('hangar-selected-actions');
        if (actionsEl) {
            actionsEl.innerHTML = '';

            if (isEquipped) {
                actionsEl.innerHTML = '<button class="btn btn-equipped" disabled>✔ EQUIPADA</button>';
            } else if (isOwned) {
                const btnEquip = document.createElement('button');
                btnEquip.className = 'btn btn-equip';
                btnEquip.innerText = 'EQUIPAR';
                btnEquip.addEventListener('click', () => {
                    window.saveManager.equipPlane(planeData.id);
                    window.sounds.playCoin();
                    this.renderHangar();
                    this.renderMenuPlanePreview();
                    this.updateTopBar();
                });
                actionsEl.appendChild(btnEquip);
            } else {
                const btnBuy = document.createElement('button');
                btnBuy.className = 'btn btn-buy';

                if (planeData.precoDiamantes > 0) {
                    btnBuy.innerHTML = `💎 ${planeData.precoDiamantes} Diamantes`;
                } else {
                    btnBuy.innerHTML = `🪙 ${planeData.precoMoedas.toLocaleString()} Moedas`;
                }

                btnBuy.addEventListener('click', () => {
                    this.buyPlane(planeData);
                });
                actionsEl.appendChild(btnBuy);
            }
        }
    }

    buyPlane(plane) {
        if (plane.precoDiamantes > 0) {
            if (window.saveManager.data.diamantes >= plane.precoDiamantes) {
                window.saveManager.addDiamonds(-plane.precoDiamantes);
                window.saveManager.unlockPlane(plane.id);
                window.saveManager.equipPlane(plane.id);
                window.sounds.playDiamond();
                alert(`Parabéns! Você adquiriu a nave militar ${plane.nome}!`);
                this.renderHangar();
                this.renderMenuPlanePreview();
                this.updateTopBar();
            } else {
                alert(`Diamantes insuficientes! Você precisa de ${plane.precoDiamantes} diamantes (tem ${window.saveManager.data.diamantes}). Obtenha passando fases sem receber dano ou use códigos no chat de cheats!`);
            }
        } else {
            if (window.saveManager.data.moedas >= plane.precoMoedas) {
                window.saveManager.addCoins(-plane.precoMoedas);
                window.saveManager.unlockPlane(plane.id);
                window.saveManager.equipPlane(plane.id);
                window.sounds.playCoin();
                alert(`Parabéns! Você adquiriu a aeronave ${plane.nome}!`);
                this.renderHangar();
                this.renderMenuPlanePreview();
                this.updateTopBar();
            } else {
                alert(`Moedas insuficientes! Você precisa de ${plane.precoMoedas.toLocaleString()} moedas (tem ${window.saveManager.data.moedas.toLocaleString()}). Destrua inimigos e cause dano para lucrar!`);
            }
        }
    }

    getCategoryDisplayName(cat) {
        const names = {
            'classicos': 'CLÁSSICOS WWII',
            'pesados': 'BOMBARDEIROS',
            'helicopteros': 'HELICÓPTEROS',
            'nacionais': 'FAB & EMBRAER',
            'comerciais': 'LATAM MILITAR',
            'orientais': 'CAÇAS ASIÁTICOS',
            'stealth': 'FURTIVOS (B-2)',
            'alienigenas': 'ALIEN / FUTURISTA'
        };
        return names[cat] || cat.toUpperCase();
    }

    // ======================== FUSION SCREEN ========================

    renderFusionScreen() {
        const owned = window.fusionSystem.getOwnedPlanes();
        const select1 = document.getElementById('fusion-select-1');
        const select2 = document.getElementById('fusion-select-2');
        const resultDiv = document.getElementById('fusion-preview-info');
        const btnFuse = document.getElementById('btn-do-fusion');

        if (!select1 || !select2) return;

        select1.innerHTML = '<option value="">Selecione a Nave Base...</option>';
        select2.innerHTML = '<option value="">Selecione a Segunda Nave...</option>';

        owned.forEach(p => {
            const lvl = window.saveManager.data.niveisNaves[p.id] || 1;
            select1.innerHTML += `<option value="${p.id}">${p.nome} (Nível ${lvl} - Tier ${p.tier})</option>`;
            select2.innerHTML += `<option value="${p.id}">${p.nome} (Nível ${lvl} - Tier ${p.tier})</option>`;
        });

        const drawFusionPlane = (canvasId, plane, level = 1, size = 72) => {
            const canvas = document.getElementById(canvasId);
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            if (plane) window.spriteRenderer.drawPlane(ctx, plane, canvas.width / 2, canvas.height / 2, size, 0, false, level);
        };

        const updatePreview = () => {
            const id1 = select1.value;
            const id2 = select2.value;
            const p1 = PLANES_DATA.find(p => p.id === id1);
            const p2 = PLANES_DATA.find(p => p.id === id2);
            drawFusionPlane('fusion-plane-1', p1, p1 ? (window.saveManager.data.niveisNaves[p1.id] || 1) : 1);
            drawFusionPlane('fusion-plane-2', p2, p2 ? (window.saveManager.data.niveisNaves[p2.id] || 1) : 1);
            if (!id1 || !id2 || id1 === id2) {
                resultDiv.innerHTML = "<p>Selecione duas naves diferentes para calcular o custo e o poder resultante da fusão.</p>";
                drawFusionPlane('fusion-result-plane', p1, p1 ? (window.saveManager.data.niveisNaves[p1.id] || 1) : 1, 98);
                btnFuse.disabled = true;
                return;
            }

            const cost = window.fusionSystem.calculateFusionCost(p1, p2);
            const currentLvl = window.saveManager.data.niveisNaves[p1.id] || 1;
            drawFusionPlane('fusion-result-plane', p1, currentLvl + 1, 98);

            resultDiv.innerHTML = `
                <div class="fusion-box-result">
                    <h4>Resultado Estimado:</h4>
                    <p><strong>${p1.nome}</strong> alcançará o <strong>Nível ${currentLvl + 1}</strong>!</p>
                    <p>⚡ Aumento de +25% de Dano e HP base!</p>
                    <p>⚠️ <strong>${p2.nome}</strong> será consumida como catalisador.</p>
                    <p>💎 Chance de despertar nave secreta de Tier Superior!</p>
                    <div class="fusion-cost-box">
                        Custo da Operação: 🪙 <strong>${cost.gold.toLocaleString()} Moedas</strong> 
                        ${cost.diamonds > 0 ? `| 💎 <strong>${cost.diamonds} Diamantes</strong>` : ''}
                    </div>
                </div>
            `;
            btnFuse.disabled = false;
        };

        select1.onchange = updatePreview;
        select2.onchange = updatePreview;

        btnFuse.onclick = () => {
            const res = window.fusionSystem.performFusion(select1.value, select2.value);
            if (res.success) {
                alert(res.message + (res.bonusPlane ? `\n\n🎉 BÔNUS DE ENGENHARIA: Você desbloqueou o lendário ${res.bonusPlane.nome}!` : ''));
                this.renderFusionScreen();
                this.updateTopBar();
            } else {
                alert(res.message);
            }
        };
    }

    // ======================== GAME CALLBACKS (VICTORY / GAME OVER) ========================

    setupGameCallbacks() {
        window.onStageVictory = (stats) => {
            this.showStageVictoryScreen(stats);
        };

        window.onGameOver = (stats) => {
            this.showGameOverScreen(stats);
        };
    }

    showStageVictoryScreen(stats) {
        this.showScreen('screen-victory');
        window.sounds.playCoin();

        const stageTitle = document.getElementById('victory-stage-num');
        const damageVal = document.getElementById('vic-damage-coins');
        const killsVal = document.getElementById('vic-kills-coins');
        const noDmgVal = document.getElementById('vic-nodamage-bonus');
        const totalCoinsVal = document.getElementById('vic-total-coins');
        const diamondBadge = document.getElementById('vic-diamond-reward');

        if (stageTitle) stageTitle.innerText = `FASE ${stats.stage} CONCLUÍDA!`;
        if (damageVal) damageVal.innerText = `+${stats.coinsFromDamage.toLocaleString()} (por dano aplicado)`;
        if (killsVal) killsVal.innerText = `+${stats.coinsFromKills.toLocaleString()} (${stats.enemiesDefeated} abatidos)`;

        if (noDmgVal) {
            noDmgVal.innerText = stats.noDamage ? "+500 Moedas (Bônus No Hit!)" : "0 (Sofreram danos)";
            noDmgVal.style.color = stats.noDamage ? "#22c55e" : "#94a3b8";
        }

        if (diamondBadge) {
            diamondBadge.style.display = stats.noDamage ? "block" : "none";
            if (stats.noDamage) {
                window.sounds.playDiamond();
            }
        }

        // Credita a recompensa antes da animação; assim ela nunca se perde se
        // o jogador tocar em "próxima fase" imediatamente.
        window.saveManager.addCoins(stats.totalCoins);
        this.updateTopBar();

        // Animação de soma progressiva das moedas
        let currentCount = 0;
        const targetTotal = stats.totalCoins;
        const step = Math.max(1, Math.floor(targetTotal / 40));

        const interval = setInterval(() => {
            currentCount += step;
            if (currentCount >= targetTotal) {
                currentCount = targetTotal;
                clearInterval(interval);
            }
            if (totalCoinsVal) totalCoinsVal.innerText = `+${currentCount.toLocaleString()} MOEDAS`;
        }, 25);

        // Botão Próxima Fase
        const btnNext = document.getElementById('btn-vic-next');
        if (btnNext) {
            btnNext.onclick = () => {
                if (stats.stage < 100) {
                    this.startStage(stats.stage + 1);
                } else {
                    alert("PARABÉNS COMANDANTE! Você zerou todas as 100 fases!");
                    this.showScreen('screen-stages');
                }
            };
        }

        // Botão Repetir
        const btnRetry = document.getElementById('btn-vic-retry');
        if (btnRetry) {
            btnRetry.onclick = () => {
                this.startStage(stats.stage);
            };
        }
    }

    showGameOverScreen(stats) {
        this.showScreen('screen-gameover');
        const coinsEl = document.getElementById('gameover-coins');
        if (coinsEl) coinsEl.innerText = stats.coinsEarned.toLocaleString();
        window.saveManager.addCoins(stats.coinsEarned);
        this.updateTopBar();

        const btnRetry = document.getElementById('btn-gameover-retry');
        if (btnRetry) {
            btnRetry.onclick = () => {
                this.startStage(stats.stage);
            };
        }
    }

    // ======================== IN-GAME HUD ========================

    updateInGameHUD() {
        const eng = window.gameEngine;
        // Barra de Vida
        const hpBar = document.getElementById('hud-hp-bar');
        const hpText = document.getElementById('hud-hp-text');
        if (hpBar) {
            const pct = Math.max(0, Math.min(100, (eng.player.hp / eng.player.maxHp) * 100));
            hpBar.style.width = pct + "%";
            hpBar.style.backgroundColor = pct > 50 ? "#22c55e" : pct > 25 ? "#f59e0b" : "#ef4444";
        }
        if (hpText) hpText.innerText = `${Math.max(0, eng.player.hp)} / ${eng.player.maxHp}`;

        // Moedas coletadas na rodada
        const currentCoinsEl = document.getElementById('hud-round-coins');
        if (currentCoinsEl) {
            currentCoinsEl.innerText = (eng.coinsFromDamage + eng.coinsFromKills).toLocaleString();
        }

        // Especial
        const specialBadge = document.getElementById('hud-special-count');
        if (specialBadge) {
            specialBadge.innerText = eng.player.specials;
        }

        // Boss Bar se estiver ativo
        const bossContainer = document.getElementById('hud-boss-wrap');
        const bossBar = document.getElementById('hud-boss-bar');
        const bossName = document.getElementById('hud-boss-name');
        if (bossContainer && bossBar && bossName) {
            if (eng.boss) {
                bossContainer.style.display = "block";
                const bPct = Math.max(0, (eng.boss.hp / eng.boss.maxHp) * 100);
                bossBar.style.width = bPct + "%";
                bossName.innerText = eng.boss.nome;
            } else {
                bossContainer.style.display = "none";
            }
        }
    }
}

window.uiManager = new UIManager();
