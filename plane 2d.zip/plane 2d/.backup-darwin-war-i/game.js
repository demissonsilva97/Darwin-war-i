// Motor de Jogo Principal de Darwin War I
// Suporta toque touch mobile com offset vertical, teclado, física, 100 fases e chefes

class GameEngine {
    constructor() {
        this.canvas = null;
        this.ctx = null;
        this.width = 480;
        this.height = 800;
        this.running = false;
        this.paused = false;

        // Jogador
        this.player = {
            x: 240,
            y: 650,
            targetX: 240,
            targetY: 650,
            vx: 0,
            vy: 0,
            tilt: 0,
            size: 54,
            hp: 100,
            maxHp: 100,
            data: null,
            level: 1,
            powerLevel: 1,
            specials: 2,
            shieldTimer: 0,
            magnetTimer: 0,
            lastShotTime: 0,
            tookDamage: false,
            invulnerableTime: 0
        };

        // Wingmen equipados
        this.leftWingman = null;
        this.rightWingman = null;

        // Entidades
        this.bullets = [];
        this.enemyBullets = [];
        this.enemies = [];
        this.particles = [];
        this.pickups = []; // moedas, estrelas, power-ups
        this.clouds = [];
        this.floatingTexts = [];

        // Chefe da Fase
        this.boss = null;
        this.bossWarning = 0;

        // Controle e Input
        this.touchActive = false;
        this.touchOffsetY = -45; // Offset suave para o dedo não cobrir a nave!
        this.keys = {};

        // Estatísticas da rodada atual
        this.stage = 1;
        this.stageTime = 0;
        this.stageCleared = false;
        this.gameOver = false;
        this.enemiesDefeated = 0;
        this.damageDealt = 0;
        this.coinsFromDamage = 0;
        this.coinsFromKills = 0;
        this.score = 0;

        // Scroll do oceano
        this.oceanScroll = 0;
        this.initialized = false;
        this.stageRunId = 0;
    }

    init(canvas) {
        // A tela de combate é reaberta muitas vezes. Não registre controles a
        // cada fase: listeners duplicados deixam o avião rápido demais e fazem
        // a bomba disparar várias vezes.
        if (this.initialized && this.canvas === canvas) {
            this.resize();
            return;
        }
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.resize();
        window.addEventListener('resize', () => this.resize());

        this.setupInputs();
        this.createOceanScenery();
        this.initialized = true;
    }

    resize() {
        const container = this.canvas.parentElement;
        const rect = container.getBoundingClientRect();
        this.width = rect.width;
        this.height = rect.height;
        const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
        this.canvas.width = Math.round(this.width * pixelRatio);
        this.canvas.height = Math.round(this.height * pixelRatio);
        this.ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    }

    createOceanScenery() {
        // Cenário de combate limpo: somente céu, nuvens e oceano.
        this.clouds = [];
        for (let i = 0; i < 5; i++) {
            this.clouds.push({
                x: Math.random() * this.width,
                y: Math.random() * this.height * 2 - this.height,
                scale: Math.random() * 0.8 + 0.6,
                speed: 1.8
            });
        }
    }

    setupInputs() {
        // Touch para celular (Estilo 1945 Air Force: dedo arrasta livremente)
        const getTouchPos = (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const touch = e.touches[0] || e.changedTouches[0];
            return {
                x: touch.clientX - rect.left,
                y: touch.clientY - rect.top + this.touchOffsetY
            };
        };

        this.canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            window.sounds.init();
            this.touchActive = true;
            const pos = getTouchPos(e);
            this.player.targetX = pos.x;
            this.player.targetY = pos.y;
        }, { passive: false });

        this.canvas.addEventListener('touchmove', (e) => {
            e.preventDefault();
            if (this.touchActive) {
                const pos = getTouchPos(e);
                this.player.targetX = pos.x;
                this.player.targetY = pos.y;
            }
        }, { passive: false });

        this.canvas.addEventListener('touchend', (e) => {
            e.preventDefault();
            this.touchActive = false;
        }, { passive: false });

        // Mouse para testes em desktop
        let isMouseDown = false;
        this.canvas.addEventListener('mousedown', (e) => {
            window.sounds.init();
            isMouseDown = true;
            const rect = this.canvas.getBoundingClientRect();
            this.player.targetX = e.clientX - rect.left;
            this.player.targetY = e.clientY - rect.top + this.touchOffsetY;
        });

        window.addEventListener('mousemove', (e) => {
            if (isMouseDown) {
                const rect = this.canvas.getBoundingClientRect();
                this.player.targetX = e.clientX - rect.left;
                this.player.targetY = e.clientY - rect.top + this.touchOffsetY;
            }
        });

        window.addEventListener('mouseup', () => {
            isMouseDown = false;
        });

        // Teclado
        window.addEventListener('keydown', (e) => {
            this.keys[e.key.toLowerCase()] = true;
            if (e.code === 'Space') {
                this.triggerSpecial();
            }
        });
        window.addEventListener('keyup', (e) => {
            this.keys[e.key.toLowerCase()] = false;
        });
    }

    startStage(stageNum) {
        ++this.stageRunId;
        this.stage = stageNum;
        this.stageTime = 0;
        this.stageCleared = false;
        this.gameOver = false;
        this.enemiesDefeated = 0;
        this.damageDealt = 0;
        this.coinsFromDamage = 0;
        this.coinsFromKills = 0;
        this.score = 0;

        // Limpar entidades
        this.bullets = [];
        this.enemyBullets = [];
        this.enemies = [];
        this.particles = [];
        this.pickups = [];
        this.floatingTexts = [];
        this.boss = null;
        this.bossWarning = 0;

        // Carregar nave equipada
        const planeId = window.saveManager.data.naveEquipada;
        this.player.data = PLANES_DATA.find(p => p.id === planeId) || PLANES_DATA[0];
        this.player.level = window.saveManager.data.niveisNaves[this.player.data.id] || 1;
        
        // Multiplicador de estatísticas por nível
        const levelBonus = 1 + (this.player.level - 1) * 0.25;
        this.player.maxHp = Math.round(this.player.data.hp * levelBonus);
        this.player.hp = this.player.maxHp;
        this.player.powerLevel = 1;
        this.player.specials = window.saveManager.data.cheats.infiniteSpecial ? 99 : 2;
        this.player.tookDamage = false;
        this.player.shieldTimer = 0;
        this.player.magnetTimer = 0;
        this.player.invulnerableTime = 120; // 2 segundos iniciais seguros
        this.player.lastShotTime = Date.now() - this.player.data.cadencia;

        // Posição inicial no centro inferior
        this.player.x = this.width / 2;
        this.player.y = this.height - 120;
        this.player.targetX = this.player.x;
        this.player.targetY = this.player.y;

        // Carregar Wingmen
        const lwId = window.saveManager.data.wingmanEsquerdo;
        const rwId = window.saveManager.data.wingmanDireito;
        this.leftWingman = lwId ? WINGMEN_DATA.find(w => w.id === lwId) : null;
        this.rightWingman = rwId ? WINGMEN_DATA.find(w => w.id === rwId) : null;

        this.running = true;
        this.paused = false;

        // Efeito de decolagem
        this.spawnTakeoffParticles();
    }

    spawnTakeoffParticles() {
        for (let i = 0; i < 20; i++) {
            this.particles.push({
                x: this.player.x + (Math.random() * 40 - 20),
                y: this.player.y + 30 + Math.random() * 15,
                vx: (Math.random() - 0.5) * 3,
                vy: Math.random() * 4 + 2,
                size: Math.random() * 6 + 4,
                color: "rgba(255, 255, 255, 0.7)",
                life: 40,
                maxLife: 40
            });
        }
    }

    triggerSpecial() {
        if (this.player.specials <= 0 && !window.saveManager.data.cheats.infiniteSpecial) return;
        if (!window.saveManager.data.cheats.infiniteSpecial) {
            this.player.specials--;
        }

        window.sounds.playBomb();

        // Onda de choque devastadora que apaga projéteis inimigos e causa alto dano
        this.enemyBullets = [];
        this.enemies.forEach(enemy => {
            const dmg = 250 * (window.saveManager.data.cheats.superDamage ? 10 : 1);
            enemy.hp -= dmg;
            this.registerDamage(dmg, enemy.x, enemy.y);
            this.createExplosion(enemy.x, enemy.y, 'small');
        });

        // Clarão visual
        this.particles.push({
            type: "screen_flash",
            life: 25,
            maxLife: 25
        });

        this.addFloatingText("ESPECIAL NUCLEAR!", this.player.x, this.player.y - 40, "#f59e0b");
    }

    registerDamage(damage, x, y) {
        this.damageDealt += damage;
        // Ganha moedas a cada dano aplicado (conforme solicitado pelo usuário!)
        const coinAmount = Math.max(1, Math.floor(damage * 0.15));
        this.coinsFromDamage += coinAmount;
        this.score += Math.round(damage * 2);

        // Chance de dropar moeda física que vai voando para o jogador
        if (Math.random() < 0.25) {
            this.pickups.push({
                type: "coin",
                x: x + (Math.random() * 20 - 10),
                y: y + (Math.random() * 20 - 10),
                value: 5,
                vy: 1.5,
                size: 10
            });
        }
    }

    update(dt = 0.016) {
        if (!this.running || this.paused) return;

        this.stageTime += dt;
        this.oceanScroll = (this.oceanScroll + 1.5) % this.height;

        // Atualizar cenário
        this.updateScenery();

        // Atualizar movimento do jogador
        this.updatePlayerMovement();

        // Atirar automaticamente
        this.handleAutoFire();

        // Gerar inimigos e ondas da fase
        this.handleEnemySpawning(dt);

        // Atualizar projéteis
        this.updateBullets();

        // Atualizar inimigos e colisões
        this.updateEnemies();

        // Atualizar pickups e ímã
        this.updatePickups();

        // Atualizar partículas e textos flutuantes
        this.updateParticles();

        // Atualizar Boss se existir
        if (this.boss) {
            this.updateBoss(dt);
        }

        // Checar fim de fase
        this.checkStageStatus();

        // Atualizar renderizador de sprites (rotação de hélices/rotores)
        window.spriteRenderer.update(dt);
    }

    updateScenery() {
        this.clouds.forEach(cloud => {
            cloud.y += cloud.speed;
            if (cloud.y > this.height + 150) {
                cloud.y = -150;
                cloud.x = Math.random() * this.width;
            }
        });
    }

    updatePlayerMovement() {
        // Teclado (WASD / Setas)
        const moveSpeed = this.player.data.velocidade * 1.2;
        if (this.keys['arrowleft'] || this.keys['a']) this.player.targetX -= moveSpeed * 3;
        if (this.keys['arrowright'] || this.keys['d']) this.player.targetX += moveSpeed * 3;
        if (this.keys['arrowup'] || this.keys['w']) this.player.targetY -= moveSpeed * 3;
        if (this.keys['arrowdown'] || this.keys['s']) this.player.targetY += moveSpeed * 3;

        // Limites da tela
        const margin = 28;
        this.player.targetX = Math.max(margin, Math.min(this.width - margin, this.player.targetX));
        this.player.targetY = Math.max(margin + 40, Math.min(this.height - margin, this.player.targetY));

        // Interpolação suave em direção ao alvo (smooth drag)
        const dx = this.player.targetX - this.player.x;
        const dy = this.player.targetY - this.player.y;
        this.player.vx = dx * 0.22;
        this.player.vy = dy * 0.22;
        this.player.x += this.player.vx;
        this.player.y += this.player.vy;

        // Inclinação lateral dinâmica (banking)
        this.player.tilt = Math.max(-1, Math.min(1, this.player.vx / 10));

        // Timers de bônus
        if (this.player.shieldTimer > 0) this.player.shieldTimer--;
        if (this.player.magnetTimer > 0) this.player.magnetTimer--;
        if (this.player.invulnerableTime > 0) this.player.invulnerableTime--;
    }

    handleAutoFire() {
        const now = Date.now();
        const fireInterval = Math.max(70, this.player.data.cadencia - (this.player.powerLevel - 1) * 12);

        if (now - this.player.lastShotTime > fireInterval) {
            this.player.lastShotTime = now;
            this.firePlayerBullets();
        }
    }

    firePlayerBullets() {
        const dmgMultiplier = (window.saveManager.data.cheats.superDamage ? 10 : 1) * (1 + (this.player.level - 1) * 0.25);
        const baseDmg = this.player.data.dano * dmgMultiplier;
        const type = this.player.data.tipoTiro;

        window.sounds.playShoot(type.includes('laser') ? 'laser' : type.includes('heavy') ? 'heavy' : 'normal');

        // Formação de tiros conforme nível de poder (powerLevel 1 a 5)
        const pLevel = this.player.powerLevel;
        const x = this.player.x;
        const y = this.player.y - 25;

        if (pLevel === 1) {
            // Tiro duplo paralelo
            this.bullets.push({ x: x - 12, y: y, vx: 0, vy: -15, damage: baseDmg, color: "#38bdf8", size: 5 });
            this.bullets.push({ x: x + 12, y: y, vx: 0, vy: -15, damage: baseDmg, color: "#38bdf8", size: 5 });
        } else if (pLevel === 2) {
            // Tiro triplo com leque leve
            this.bullets.push({ x: x, y: y - 5, vx: 0, vy: -16, damage: baseDmg * 1.1, color: "#facc15", size: 6 });
            this.bullets.push({ x: x - 15, y: y, vx: -1.8, vy: -15, damage: baseDmg, color: "#38bdf8", size: 5 });
            this.bullets.push({ x: x + 15, y: y, vx: 1.8, vy: -15, damage: baseDmg, color: "#38bdf8", size: 5 });
        } else if (pLevel === 3) {
            // Tiro quádruplo reforçado
            [-20, -7, 7, 20].forEach((ox, idx) => {
                const angle = (idx - 1.5) * 1.5;
                this.bullets.push({ x: x + ox, y: y, vx: angle, vy: -16, damage: baseDmg * 1.1, color: "#f97316", size: 6 });
            });
        } else if (pLevel >= 4) {
            // Tiro 5x com mísseis secundários teleguiados
            [-24, -12, 0, 12, 24].forEach((ox, idx) => {
                const angle = (idx - 2) * 2.2;
                this.bullets.push({ x: x + ox, y: y, vx: angle, vy: -17, damage: baseDmg * 1.2, color: "#ec4899", size: 7 });
            });
            // Míssil inteligente
            if (this.enemies.length > 0) {
                this.bullets.push({
                    x: x,
                    y: y,
                    vx: 0,
                    vy: -12,
                    damage: baseDmg * 2.0,
                    color: "#ef4444",
                    size: 8,
                    homing: true
                });
            }
        }

        // Wingmen atirando
        if (this.leftWingman) {
            this.bullets.push({
                x: this.player.x - 38,
                y: this.player.y + 10,
                vx: -0.5,
                vy: -15,
                damage: this.leftWingman.dano * dmgMultiplier,
                color: this.leftWingman.cor || "#38bdf8",
                size: 4
            });
        }
        if (this.rightWingman) {
            this.bullets.push({
                x: this.player.x + 38,
                y: this.player.y + 10,
                vx: 0.5,
                vy: -15,
                damage: this.rightWingman.dano * dmgMultiplier,
                color: this.rightWingman.cor || "#38bdf8",
                size: 4
            });
        }
    }

    handleEnemySpawning(dt) {
        // Se o chefe já está em combate ou fase concluída, não gera esquadrilhas comuns
        if (this.boss || this.stageCleared) return;

        // Frequência de esquadrilhas baseada no número da fase
        const spawnInterval = Math.max(1.8, 3.8 - (this.stage * 0.02));
        if (this.stageTime % spawnInterval < dt) {
            this.spawnEnemyFormation();
        }

        // Condição para o BOSS surgir (após cerca de 25 segundos de combate)
        if (this.stageTime > 26 && !this.boss && !this.stageCleared) {
            this.spawnBoss();
        }
    }

    spawnEnemyFormation() {
        const runId = this.stageRunId;
        const types = ["fighter", "bomber", "chopper"];
        const chosen = types[Math.floor(Math.random() * types.length)];
        const count = 3 + Math.min(4, Math.floor(this.stage / 20));
        const startX = Math.random() * (this.width - 140) + 70;
        const hpMultiplier = 1 + this.stage * 0.12;

        for (let i = 0; i < count; i++) {
            setTimeout(() => {
                if (!this.running || this.stageCleared || runId !== this.stageRunId) return;
                let hp = chosen === "bomber" ? 75 : chosen === "chopper" ? 50 : 30;
                hp *= hpMultiplier;

                this.enemies.push({
                    type: chosen,
                    x: startX + (Math.random() * 40 - 20),
                    y: -50,
                    vx: (Math.random() - 0.5) * 1.5,
                    vy: chosen === "bomber" ? 1.8 : 2.6,
                    hp: hp,
                    maxHp: hp,
                    size: chosen === "bomber" ? 44 : chosen === "chopper" ? 38 : 32,
                    lastFire: Date.now() + Math.random() * 1500,
                    scoreVal: chosen === "bomber" ? 150 : 80
                });
            }, i * 320);
        }
    }

    spawnBoss() {
        const runId = this.stageRunId;
        window.sounds.playBossAlarm();
        this.bossWarning = 180; // 3 segundos de aviso piscando na tela

        setTimeout(() => {
            if (!this.running || this.stageCleared || runId !== this.stageRunId) return;

            // Tipos de Chefes:
            // Fases normais / navais: Dreadnought Encouraçado de Guerra com torres giratórias
            // A cada 10 fases: Chefes colossais aéreos ou alienígenas
            const isAlien = this.stage % 20 === 0;
            const isSuperAir = this.stage % 10 === 0 && !isAlien;
            const bossHp = (800 + this.stage * 180) * (isAlien ? 1.5 : 1);

            let turrets = [];
            if (!isAlien && !isSuperAir) {
                // Navio encouraçado com 4 torres de artilharia
                turrets = [
                    { x: 0, y: -80, angle: 0, hp: 150 },
                    { x: 0, y: -30, angle: 0, hp: 150 },
                    { x: 0, y: 30, angle: 0, hp: 150 },
                    { x: 0, y: 80, angle: 0, hp: 150 }
                ];
            }

            this.boss = {
                type: isAlien ? "alien_mothership" : isSuperAir ? "sky_titan" : "warship",
                nome: isAlien ? "Nave-Mãe Xenon" : isSuperAir ? "Bombardeiro Titã XB-9" : "Encouraçado Imperial Yamato",
                x: this.width / 2,
                y: -140,
                targetY: 160,
                vx: 1.2,
                hp: bossHp,
                maxHp: bossHp,
                width: isAlien ? 160 : isSuperAir ? 220 : 130,
                height: isAlien ? 160 : isSuperAir ? 140 : 260,
                turrets: turrets,
                attackPattern: 0,
                lastAttack: Date.now()
            };
        }, 3000);
    }

    updateBoss(dt) {
        if (!this.boss) return;

        // Entrada triunfal
        if (this.boss.y < this.boss.targetY) {
            this.boss.y += 1.5;
        } else {
            // Movimento lateral contínuo
            this.boss.x += this.boss.vx;
            if (this.boss.x < 100 || this.boss.x > this.width - 100) {
                this.boss.vx *= -1;
            }
        }

        // Mira das torres do navio na direção do jogador
        if (this.boss.turrets) {
            this.boss.turrets.forEach(t => {
                const worldX = this.boss.x + t.x;
                const worldY = this.boss.y + t.y;
                t.angle = Math.atan2(this.player.y - worldY, this.player.x - worldX) + Math.PI / 2;
            });
        }

        // Ataques do Chefe
        const now = Date.now();
        if (now - this.boss.lastAttack > 1600) {
            this.boss.lastAttack = now;
            this.bossFirePattern();
        }
    }

    bossFirePattern() {
        if (!this.boss) return;
        const bx = this.boss.x;
        const by = this.boss.y;

        // Padrão de tiros em espiral ou leque pesado
        const count = 8 + Math.min(8, Math.floor(this.stage / 15));
        for (let i = 0; i < count; i++) {
            const angle = (Math.PI * 2 / count) * i + (this.stageTime * 2);
            const speed = 4.2;
            this.enemyBullets.push({
                x: bx,
                y: by + 20,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                color: "#ef4444",
                size: 7
            });
        }

        // Tiros direcionados nas torres
        if (this.boss.turrets) {
            this.boss.turrets.forEach(t => {
                const wx = bx + t.x;
                const wy = by + t.y;
                const angle = Math.atan2(this.player.y - wy, this.player.x - wx);
                this.enemyBullets.push({
                    x: wx,
                    y: wy,
                    vx: Math.cos(angle) * 5.5,
                    vy: Math.sin(angle) * 5.5,
                    color: "#f97316",
                    size: 6
                });
            });
        }

        window.sounds.playShoot('heavy');
    }

    updateBullets() {
        // Projéteis do Jogador
        for (let i = this.bullets.length - 1; i >= 0; i--) {
            const b = this.bullets[i];

            // Se for míssil teleguiado
            if (b.homing && this.enemies.length > 0) {
                const target = this.enemies[0];
                const angle = Math.atan2(target.y - b.y, target.x - b.x);
                b.vx += Math.cos(angle) * 0.8;
                b.vy += Math.sin(angle) * 0.8;
            }

            b.x += b.vx;
            b.y += b.vy;

            // Fora da tela
            if (b.y < -30 || b.x < -30 || b.x > this.width + 30) {
                this.bullets.splice(i, 1);
                continue;
            }

            // Colisão com inimigos comuns
            let hit = false;
            for (let j = this.enemies.length - 1; j >= 0; j--) {
                const e = this.enemies[j];
                const dist = Math.hypot(b.x - e.x, b.y - e.y);
                if (dist < e.size * 0.6 + b.size) {
                    e.hp -= b.damage;
                    this.registerDamage(b.damage, e.x, e.y);
                    this.createHitSparks(b.x, b.y);
                    hit = true;

                    if (e.hp <= 0) {
                        this.destroyEnemy(e, j);
                    }
                    break;
                }
            }

            // Colisão com o Boss
            if (!hit && this.boss) {
                const dist = Math.hypot(b.x - this.boss.x, b.y - this.boss.y);
                if (dist < this.boss.width * 0.45 + b.size) {
                    this.boss.hp -= b.damage;
                    this.registerDamage(b.damage, b.x, b.y);
                    this.createHitSparks(b.x, b.y);
                    hit = true;

                    if (this.boss.hp <= 0) {
                        this.destroyBoss();
                    }
                }
            }

            if (hit) {
                this.bullets.splice(i, 1);
            }
        }

        // Projéteis dos Inimigos
        for (let i = this.enemyBullets.length - 1; i >= 0; i--) {
            const eb = this.enemyBullets[i];
            eb.x += eb.vx;
            eb.y += eb.vy;

            if (eb.y > this.height + 40 || eb.x < -40 || eb.x > this.width + 40) {
                this.enemyBullets.splice(i, 1);
                continue;
            }

            // Colisão com o Jogador
            const pDist = Math.hypot(eb.x - this.player.x, eb.y - this.player.y);
            if (pDist < this.player.size * 0.35 + eb.size) {
                this.hitPlayer(20);
                this.enemyBullets.splice(i, 1);
            }
        }
    }

    hitPlayer(damage) {
        // Se estiver com invencibilidade ou cheat GodMode ativo
        if (window.saveManager.data.cheats.godmode || this.player.invulnerableTime > 0) {
            return;
        }

        // Se estiver com escudo temporário ativo
        if (this.player.shieldTimer > 0) {
            this.createExplosion(this.player.x, this.player.y, 'small');
            return;
        }

        this.player.hp -= damage;
        this.player.tookDamage = true; // Perde o bônus de "No Damage"
        this.player.invulnerableTime = 60; // 1 segundo de piscar invulnerável após ser atingido
        window.sounds.playExplosion('small');

        this.addFloatingText("- " + damage, this.player.x, this.player.y - 30, "#ef4444");

        if (this.player.hp <= 0) {
            this.triggerGameOver();
        }
    }

    updateEnemies() {
        for (let i = this.enemies.length - 1; i >= 0; i--) {
            const e = this.enemies[i];
            e.x += e.vx;
            e.y += e.vy;

            // Inimigos atiram na direção do jogador de tempos em tempos
            const now = Date.now();
            if (now - e.lastFire > 2200 && e.y > 40 && e.y < this.height - 150) {
                e.lastFire = now;
                const angle = Math.atan2(this.player.y - e.y, this.player.x - e.x);
                this.enemyBullets.push({
                    x: e.x,
                    y: e.y + 15,
                    vx: Math.cos(angle) * 4.0,
                    vy: Math.sin(angle) * 4.0,
                    color: "#f87171",
                    size: 5
                });
            }

            // Fora da tela
            if (e.y > this.height + 60) {
                this.enemies.splice(i, 1);
                continue;
            }

            // Colisão corpo-a-corpo com o jogador
            const dist = Math.hypot(e.x - this.player.x, e.y - this.player.y);
            if (dist < (e.size + this.player.size) * 0.4) {
                this.hitPlayer(35);
                this.destroyEnemy(e, i);
            }
        }
    }

    destroyEnemy(enemy, index) {
        this.enemies.splice(index, 1);
        this.enemiesDefeated++;
        this.coinsFromKills += 15;
        this.score += enemy.scoreVal || 100;
        window.sounds.playExplosion('small');
        this.createExplosion(enemy.x, enemy.y, 'medium');

        // Drop de itens (Power-up, Bomba, Escudo, Vida)
        const rand = Math.random();
        if (rand < 0.14) {
            this.pickups.push({ type: "power", x: enemy.x, y: enemy.y, vy: 1.2, size: 14 });
        } else if (rand < 0.20) {
            this.pickups.push({ type: "bomb", x: enemy.x, y: enemy.y, vy: 1.2, size: 14 });
        } else if (rand < 0.26) {
            this.pickups.push({ type: "health", x: enemy.x, y: enemy.y, vy: 1.2, size: 14 });
        } else if (rand < 0.32) {
            this.pickups.push({ type: "shield", x: enemy.x, y: enemy.y, vy: 1.2, size: 14 });
        } else {
            // Moeda dourada dropada
            this.pickups.push({ type: "coin", x: enemy.x, y: enemy.y, value: 10, vy: 1.5, size: 11 });
        }
    }

    destroyBoss() {
        window.sounds.playExplosion('boss');
        this.createExplosion(this.boss.x, this.boss.y, 'boss');

        // Drop maciço de moedas do chefe
        for (let i = 0; i < 25; i++) {
            this.pickups.push({
                type: "coin",
                x: this.boss.x + (Math.random() * 80 - 40),
                y: this.boss.y + (Math.random() * 80 - 40),
                value: 20,
                vy: Math.random() * 2 + 1,
                size: 12
            });
        }

        this.score += 5000 + this.stage * 200;
        this.boss = null;
        this.stageCleared = true;

        const runId = this.stageRunId;
        setTimeout(() => {
            if (runId === this.stageRunId && this.stageCleared) this.finishStageVictory();
        }, 2000);
    }

    updatePickups() {
        const hasMagnet = this.player.magnetTimer > 0;

        for (let i = this.pickups.length - 1; i >= 0; i--) {
            const p = this.pickups[i];
            p.y += p.vy;

            // Efeito de sucção magnética em direção ao avião
            const dist = Math.hypot(p.x - this.player.x, p.y - this.player.y);
            if (hasMagnet || dist < 120) {
                const angle = Math.atan2(this.player.y - p.y, this.player.x - p.x);
                p.x += Math.cos(angle) * 7.5;
                p.y += Math.sin(angle) * 7.5;
            }

            // Coleta
            if (dist < this.player.size * 0.45 + p.size) {
                this.collectPickup(p);
                this.pickups.splice(i, 1);
                continue;
            }

            if (p.y > this.height + 40) {
                this.pickups.splice(i, 1);
            }
        }
    }

    collectPickup(item) {
        if (item.type === "coin") {
            window.sounds.playCoin();
            this.coinsFromKills += item.value || 10;
            this.addFloatingText(`+${item.value}`, item.x, item.y, "#facc15");
        } else if (item.type === "power") {
            window.sounds.playPowerUp();
            this.player.powerLevel = Math.min(5, this.player.powerLevel + 1);
            this.addFloatingText("POWER UP!", this.player.x, this.player.y - 35, "#38bdf8");
        } else if (item.type === "bomb") {
            window.sounds.playPowerUp();
            this.player.specials++;
            this.addFloatingText("+1 ESPECIAL!", this.player.x, this.player.y - 35, "#f59e0b");
        } else if (item.type === "health") {
            window.sounds.playPowerUp();
            this.player.hp = Math.min(this.player.maxHp, this.player.hp + Math.round(this.player.maxHp * 0.35));
            this.addFloatingText("REPARO DE FUSELAGEM!", this.player.x, this.player.y - 35, "#22c55e");
        } else if (item.type === "shield") {
            window.sounds.playPowerUp();
            this.player.shieldTimer = 300; // 5 segundos de escudo
            this.addFloatingText("ESCUDO ATIVO!", this.player.x, this.player.y - 35, "#a855f7");
        }
    }

    createExplosion(x, y, size = 'small') {
        const count = size === 'boss' ? 70 : size === 'medium' ? 30 : 15;
        const colors = ["#ef4444", "#f97316", "#facc15", "#ffffff"];

        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = Math.random() * (size === 'boss' ? 8 : 4) + 1;
            this.particles.push({
                x: x,
                y: y,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                size: Math.random() * (size === 'boss' ? 9 : 5) + 3,
                color: colors[Math.floor(Math.random() * colors.length)],
                life: Math.random() * 25 + 15,
                maxLife: 40
            });
        }
    }

    createHitSparks(x, y) {
        for (let i = 0; i < 4; i++) {
            this.particles.push({
                x: x,
                y: y,
                vx: (Math.random() - 0.5) * 6,
                vy: (Math.random() - 0.5) * 6,
                size: 3,
                color: "#fef08a",
                life: 12,
                maxLife: 12
            });
        }
    }

    addFloatingText(text, x, y, color = "#fff") {
        this.floatingTexts.push({
            text: text,
            x: x,
            y: y,
            color: color,
            life: 45,
            maxLife: 45
        });
    }

    updateParticles() {
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.life--;
            if (p.type === "screen_flash") {
                if (p.life <= 0) this.particles.splice(i, 1);
                continue;
            }
            p.x += p.vx;
            p.y += p.vy;
            p.size *= 0.96;
            if (p.life <= 0 || p.size < 0.5) {
                this.particles.splice(i, 1);
            }
        }

        for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
            const t = this.floatingTexts[i];
            t.life--;
            t.y -= 0.8;
            if (t.life <= 0) {
                this.floatingTexts.splice(i, 1);
            }
        }
    }

    checkStageStatus() {
        // Se o tempo da fase passar de 45 segundos sem boss, força o surgimento
        if (this.stageTime > 45 && !this.boss && !this.stageCleared) {
            this.spawnBoss();
        }
    }

    finishStageVictory() {
        this.running = false;
        // Salvar progresso
        const result = window.saveManager.completeStage(this.stage, this.score, this.player.tookDamage);

        // Disparar evento para a UI abrir a tela de soma das moedas
        if (window.onStageVictory) {
            window.onStageVictory({
                stage: this.stage,
                score: this.score,
                damageDealt: Math.round(this.damageDealt),
                coinsFromDamage: this.coinsFromDamage,
                enemiesDefeated: this.enemiesDefeated,
                coinsFromKills: this.coinsFromKills,
                noDamage: !this.player.tookDamage,
                diamondBonus: result.diamondEarned,
                totalCoins: this.coinsFromDamage + this.coinsFromKills + (!this.player.tookDamage ? 500 : 0)
            });
        }
    }

    triggerGameOver() {
        this.running = false;
        this.gameOver = true;
        if (window.onGameOver) {
            window.onGameOver({
                stage: this.stage,
                score: this.score,
                coinsEarned: this.coinsFromDamage + this.coinsFromKills
            });
        }
    }

    render() {
        const ctx = this.ctx;
        ctx.clearRect(0, 0, this.width, this.height);

        // 1. Fundo do Oceano Pacífico (Gradiente Azul Marinho com Ondas)
        const seaGrad = ctx.createLinearGradient(0, 0, 0, this.height);
        seaGrad.addColorStop(0, "#082f49"); // azul oceano profundo
        seaGrad.addColorStop(1, "#075985");
        ctx.fillStyle = seaGrad;
        ctx.fillRect(0, 0, this.width, this.height);

        // Ondas animadas sutis
        ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
        ctx.lineWidth = 2;
        const waveOffset = (Date.now() * 0.02) % 40;
        for (let y = -40; y < this.height + 40; y += 35) {
            ctx.beginPath();
            ctx.moveTo(0, y + waveOffset);
            for (let x = 0; x <= this.width; x += 40) {
                ctx.quadraticCurveTo(x + 20, y + waveOffset + Math.sin(x * 0.05 + this.stageTime) * 6, x + 40, y + waveOffset);
            }
            ctx.stroke();
        }

        // 2. Chefe (Navio de Guerra ou Nave Colossal)
        if (this.boss) {
            if (this.boss.type === "warship") {
                window.spriteRenderer.drawWarship(
                    ctx,
                    this.boss.x,
                    this.boss.y,
                    this.boss.width,
                    this.boss.height,
                    this.boss.turrets,
                    this.boss.hp / this.boss.maxHp
                );
            } else {
                // Nave Chefe Aérea ou Alien
                window.spriteRenderer.drawPlane(
                    ctx,
                    {
                        forma: this.boss.type === "alien_mothership" ? "disco_alien" : "hexa_motor",
                        corPrincipal: this.boss.type === "alien_mothership" ? "#1e1b4b" : "#1e293b",
                        corSecundaria: this.boss.type === "alien_mothership" ? "#22c55e" : "#ef4444"
                    },
                    this.boss.x,
                    this.boss.y,
                    this.boss.width,
                    0,
                    false
                );
            }
        }

        // 4. Inimigos
        this.enemies.forEach(e => {
            const fakeData = {
                forma: e.type === "chopper" ? "helicoptero_ataque" : e.type === "bomber" ? "quadrimotor" : "monoplano",
                corPrincipal: e.type === "chopper" ? "#44403c" : e.type === "bomber" ? "#3f4639" : "#991b1b",
                corSecundaria: "#facc15"
            };
            window.spriteRenderer.drawPlane(ctx, fakeData, e.x, e.y, e.size, 0, false);
        });

        // 5. Pickups (Moedas, Power-ups)
        this.pickups.forEach(p => {
            ctx.save();
            ctx.translate(p.x, p.y);
            if (p.type === "coin") {
                // Moeda dourada brilhante
                ctx.fillStyle = "#eab308";
                ctx.beginPath();
                ctx.arc(0, 0, p.size, 0, Math.PI * 2);
                ctx.fill();
                ctx.strokeStyle = "#fef08a";
                ctx.lineWidth = 2;
                ctx.stroke();
                ctx.fillStyle = "#713f12";
                ctx.font = "bold 9px sans-serif";
                ctx.textAlign = "center";
                ctx.textBaseline = "middle";
                ctx.fillText("$", 0, 0);
            } else {
                // Caixa de Power-up estilo arcade 1945
                const colors = { power: "#0284c7", bomb: "#ea580c", health: "#16a34a", shield: "#9333ea" };
                const labels = { power: "P", bomb: "B", health: "H", shield: "S" };
                ctx.fillStyle = colors[p.type] || "#3b82f6";
                ctx.fillRect(-p.size, -p.size, p.size * 2, p.size * 2);
                ctx.strokeStyle = "#fff";
                ctx.lineWidth = 2;
                ctx.strokeRect(-p.size, -p.size, p.size * 2, p.size * 2);

                ctx.fillStyle = "#ffffff";
                ctx.font = "bold 13px sans-serif";
                ctx.textAlign = "center";
                ctx.textBaseline = "middle";
                ctx.fillText(labels[p.type] || "P", 0, 1);
            }
            ctx.restore();
        });

        // 6. Projéteis do Jogador
        this.bullets.forEach(b => {
            ctx.fillStyle = b.color || "#38bdf8";
            ctx.beginPath();
            ctx.arc(b.x, b.y, b.size, 0, Math.PI * 2);
            ctx.fill();
        });

        // 7. Projéteis dos Inimigos
        this.enemyBullets.forEach(eb => {
            ctx.fillStyle = eb.color || "#ef4444";
            ctx.beginPath();
            ctx.arc(eb.x, eb.y, eb.size, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = "#fee2e2";
            ctx.lineWidth = 1.5;
            ctx.stroke();
        });

        // 8. Wingmen de Suporte (à esquerda e à direita)
        if (this.leftWingman) {
            window.spriteRenderer.drawWingman(ctx, this.leftWingman, this.player.x - 38, this.player.y + 12);
        }
        if (this.rightWingman) {
            window.spriteRenderer.drawWingman(ctx, this.rightWingman, this.player.x + 38, this.player.y + 12);
        }

        // 9. Jogador
        const isBlinking = this.player.invulnerableTime > 0 && Math.floor(Date.now() / 100) % 2 === 0;
        if (!isBlinking && this.player.data) {
            window.spriteRenderer.drawPlane(
                ctx,
                this.player.data,
                this.player.x,
                this.player.y,
                this.player.size,
                this.player.tilt,
                true,
                this.player.level
            );
        }

        // Escudo em bolha azul se estiver ativo
        if (this.player.shieldTimer > 0) {
            ctx.save();
            ctx.strokeStyle = `rgba(168, 85, 247, ${0.5 + 0.3 * Math.sin(Date.now() * 0.01)})`;
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(this.player.x, this.player.y, this.player.size * 0.65, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
        }

        // 10. Nuvens Translúcidas por cima da batalha
        this.clouds.forEach(c => {
            ctx.fillStyle = "rgba(255, 255, 255, 0.25)";
            ctx.beginPath();
            ctx.arc(c.x, c.y, 40 * c.scale, 0, Math.PI * 2);
            ctx.arc(c.x + 30 * c.scale, c.y - 10 * c.scale, 35 * c.scale, 0, Math.PI * 2);
            ctx.arc(c.x - 30 * c.scale, c.y + 5 * c.scale, 30 * c.scale, 0, Math.PI * 2);
            ctx.fill();
        });

        // 11. Partículas e Explosões
        this.particles.forEach(p => {
            if (p.type === "screen_flash") {
                ctx.fillStyle = `rgba(255, 255, 255, ${p.life / p.maxLife * 0.8})`;
                ctx.fillRect(0, 0, this.width, this.height);
                return;
            }
            ctx.fillStyle = p.color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        });

        // 12. Textos Flutuantes
        this.floatingTexts.forEach(t => {
            ctx.fillStyle = t.color;
            ctx.font = "bold 14px 'Segoe UI', Tahoma, sans-serif";
            ctx.textAlign = "center";
            ctx.fillText(t.text, t.x, t.y);
        });

        // 13. Alerta de BOSS
        if (this.bossWarning > 0) {
            this.bossWarning--;
            if (Math.floor(Date.now() / 250) % 2 === 0) {
                ctx.fillStyle = "rgba(220, 38, 38, 0.85)";
                ctx.fillRect(0, this.height * 0.35, this.width, 70);
                ctx.fillStyle = "#ffffff";
                ctx.font = "900 24px 'Impact', sans-serif";
                ctx.textAlign = "center";
                ctx.fillText("ALERTA: FORÇA HOSTIL DETECTADA!", this.width / 2, this.height * 0.35 + 42);
            }
        }
    }
}

window.gameEngine = new GameEngine();
