// Sistema de Fusão de Naves - Oficina de Engenharia Bélica
class FusionSystem {
    constructor() {
        this.selectedBaseId = null;
        this.selectedMaterialId = null;
    }

    getOwnedPlanes() {
        const ownedIds = window.saveManager.data.navesPossuidas;
        return PLANES_DATA.filter(p => ownedIds.includes(p.id));
    }

    calculateFusionCost(plane1, plane2) {
        const avgTier = Math.max(plane1.tier, plane2.tier);
        const goldCost = avgTier * 5000;
        const diamondCost = avgTier >= 4 ? 10 : 0;
        return { gold: goldCost, diamonds: diamondCost };
    }

    canFuse(plane1Id, plane2Id) {
        if (!plane1Id || !plane2Id || plane1Id === plane2Id) return { ok: false, reason: "Selecione duas naves diferentes." };
        const owned = window.saveManager.data.navesPossuidas;
        if (!owned.includes(plane1Id) || !owned.includes(plane2Id)) {
            return { ok: false, reason: "As duas aeronaves precisam estar no seu hangar." };
        }
        const p1 = PLANES_DATA.find(p => p.id === plane1Id);
        const p2 = PLANES_DATA.find(p => p.id === plane2Id);
        if (!p1 || !p2) return { ok: false, reason: "Naves inválidas." };

        const cost = this.calculateFusionCost(p1, p2);
        if (window.saveManager.data.moedas < cost.gold) {
            return { ok: false, reason: `Moedas insuficientes. Custo: ${cost.gold} moedas.` };
        }
        if (window.saveManager.data.diamantes < cost.diamonds) {
            return { ok: false, reason: `Diamantes insuficientes. Custo: ${cost.diamonds} diamantes.` };
        }

        return { ok: true, p1, p2, cost };
    }

    performFusion(p1Id, p2Id) {
        const check = this.canFuse(p1Id, p2Id);
        if (!check.ok) return { success: false, message: check.reason };

        const { p1, p2, cost } = check;

        // Deduz custos
        window.saveManager.addCoins(-cost.gold);
        if (cost.diamonds > 0) window.saveManager.addDiamonds(-cost.diamonds);

        // Aumenta nível da nave base
        const currentLevel = window.saveManager.data.niveisNaves[p1.id] || 1;
        const newLevel = currentLevel + 1;
        window.saveManager.data.niveisNaves[p1.id] = newLevel;

        // O catalisador é um recurso real, não apenas uma seleção visual.
        const materialIndex = window.saveManager.data.navesPossuidas.indexOf(p2.id);
        if (materialIndex >= 0) window.saveManager.data.navesPossuidas.splice(materialIndex, 1);
        delete window.saveManager.data.niveisNaves[p2.id];
        if (window.saveManager.data.naveEquipada === p2.id) {
            window.saveManager.data.naveEquipada = p1.id;
        }

        // Bônus de chance de descobrir uma nave secreta de tier superior se for nível 3+
        let bonusPlaneUnlocked = null;
        if (newLevel >= 3) {
            const nextTier = Math.min(5, p1.tier + 1);
            const candidates = PLANES_DATA.filter(p => p.tier === nextTier && !window.saveManager.data.navesPossuidas.includes(p.id));
            if (candidates.length > 0) {
                const lucky = candidates[Math.floor(Math.random() * candidates.length)];
                window.saveManager.unlockPlane(lucky.id);
                bonusPlaneUnlocked = lucky;
            }
        }

        window.saveManager.save();
        window.sounds.playFusion();

        return {
            success: true,
            plane: p1,
            newLevel: newLevel,
            bonusPlane: bonusPlaneUnlocked,
            message: `FUSÃO COMPLETA! ${p2.nome} foi consumida e ${p1.nome} alcançou o Nível ${newLevel} (+25% de Poder de Fogo e HP)!`
        };
    }
}

window.fusionSystem = new FusionSystem();
