// Service Worker para Darwin War I
const CACHE_NAME = 'darwin-war-i-cache-v3';
const DARWIN_SPRITES = Array.from(
  { length: 60 },
  (_, index) => `./assets/aircraft/darwin/dw_${String(index + 1).padStart(2, '0')}.png`
);
const ASSETS = [
  './',
  './index.html',
  './css/style.css',
  './js/audio.js',
  './js/planes_data.js',
  './js/sprites.js',
  './js/save.js',
  './js/fusion.js',
  './js/cheats.js',
  './js/game.js',
  './js/ui.js',
  './manifest.json',
  './assets/icon-192.png',
  './assets/icon-512.png',
  ...DARWIN_SPRITES
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((k) => {
          if (k !== CACHE_NAME) return caches.delete(k);
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  e.respondWith(
    caches.match(e.request).then((res) => res || fetch(e.request))
  );
});
